﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;

namespace OIMS.BL
{
  public  class Invoice_CustomerBL
    {
      Invoice_CustomerDAL dal = null;
        public Invoice_CustomerBL()
        {
            dal = new Invoice_CustomerDAL();
        }

      public static bool ValidateCustomer(Invoice_Customer Icust)
        {
            bool CustomerValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (Icust.CustomerName.Trim() == String.Empty)
                {
                    CustomerValidated = false;
                    message.Append("Customer name should be provided\n");
                }
                else if (!Regex.IsMatch(Icust.CustomerName, "[A-Z][a-z]+"))
                {
                    CustomerValidated = false;
                    message.Append("Customer name should have alphabets only and should start with Capital Letter \n");
                }

                if (Icust.Contact.Trim() == String.Empty)
                {
                    CustomerValidated = false;
                    message.Append("Contact Number Should be provided");
                }
                else if (!Regex.IsMatch(Icust.Contact, "[7-9]{1}[0-9]{9}"))
                {
                    CustomerValidated = false;
                    message.Append("Contact Number should start with (7,8 or 9) and should have 10 digits\n");
                }


                if (Icust.Email.Trim() == String.Empty)
                {
                    CustomerValidated = false;
                    message.Append("Email Should be provided");
                }
                else if (!Regex.IsMatch(Icust.Email, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
                {
                    CustomerValidated = false;
                    message.Append(" Enter a valid Email \n");

                }
                //else if (!Regex.IsMatch(Icust.Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
                //{
                //    CustomerValidated = false;
                //    message.Append(" Enter a valid Email \n");
                //}


                if (Icust.Address.Trim() == String.Empty)
                {
                    CustomerValidated = false;
                    message.Append(" Address Should be provided");
                }

                if (Icust.City.Trim() == String.Empty)
                {
                    CustomerValidated = false;
                    message.Append(" City Should be provided");
                }
                else if (!Regex.IsMatch(Icust.City,"[a-zA-Z]{3,}"))
                {
                    CustomerValidated = false;
                    message.Append("City name should have minimum 3 Characters\n");
                }

                if (Icust.Pincode.Trim() == String.Empty)
                {
                    CustomerValidated = false;
                    message.Append(" Pincode Should be provided");
                }
                else if (!Regex.IsMatch(Icust.Pincode, "[1-9]{1}[0-9]{5}"))
                {
                    CustomerValidated = false;
                    message.Append("Pincode Should have 6 digits and can't start with zero\n");
                }

          if (CustomerValidated == false)
              throw new Invoice_CustomerExceptions(message.ToString());
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return CustomerValidated;
        }

      public List<Invoice_Customer> GetAll()
      {
          return dal.SelectAll();
      }

      public static int InsertCustomer(Invoice_Customer Icust)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateCustomer(Icust))
                {
                    recordsAffected = Invoice_CustomerDAL.InsertCustomer(Icust);
                }
                else
                    throw new Invoice_CustomerExceptions("Please provide valid Category Information");
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

      public static int UpdateCustomer(Invoice_Customer Icust)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateCustomer(Icust))
                {
                    recordsAffected = Invoice_CustomerDAL.UpdateCustomer(Icust);
                }
                else
                    throw new Invoice_CustomerExceptions("Please provide valid Student Information");
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

      public static int DeleteCustomer(int custId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_CustomerDAL.DeleteCustomer(custId);
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

      public static Invoice_Customer SearchCustomer(int custId)
        {
            Invoice_Customer cust = null;

            try
            {
                cust = Invoice_CustomerDAL.SearchCustomer(custId);
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }

      public static List<Invoice_Customer> DisplayCustomer()
        {
            List<Invoice_Customer> custList = null;

            try
            {
                custList = Invoice_CustomerDAL.DisplayCustomer();
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custList;
        }

    }
}
