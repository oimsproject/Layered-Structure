﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;

namespace OIMS.BL
{
   public class Invoice_OrderDetailsBL
   {
       Invoice_OrderDetailsDAL dal = new Invoice_OrderDetailsDAL();
       public static bool ValildateOrder(Invoice_OrderDetails ord)
       {
           bool orderValidated = true;
           StringBuilder message = new StringBuilder();

           try
           {

               if (ord.UnitPrice == null)
               {
                   orderValidated = false;
                   message.Append("Unit Price should be provided and cannot be null\n");
               }
               else if(ord.UnitPrice<0)
               {
                   orderValidated = false;
                   message.Append("Unit price can't be negative");
               }
               

               if (ord.Quantity == null)
               {
                   orderValidated = false;
                   message.Append("Quantity should be provided and cannot be null\n");
               }
               else if(ord.Quantity<0)
               {
                   orderValidated = false;
                   message.Append("Order Quantity can't be negative");
               }



               if (orderValidated == false)
               {
                   throw new Invoice_OrderDetailsExceptions(message.ToString());
               }
           }
           catch (Invoice_OrderDetailsExceptions ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return orderValidated;
       }


       public static int InsertDetails(Invoice_OrderDetails ordet)
       {
           int recordsAffected;

           try
           {
               recordsAffected = Invoice_OrderDetailsDAL.InsertDetails(ordet);
           }
           catch (Invoice_OrderDetailsExceptions ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       public static int UpdateDetails(Invoice_OrderDetails ordet)
       {
           int recordsAffected;

           try
           {
               recordsAffected = Invoice_OrderDetailsDAL.UpdateDetails(ordet);
           }
           catch (Invoice_OrderDetailsExceptions ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       public static int DeleteDetails(int ordet)
       {
           int recordsAffected;

           try
           {
               recordsAffected = Invoice_OrderDetailsDAL.DeleteDetails(ordet);
           }
           catch (Invoice_OrderDetailsExceptions ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       public static Invoice_OrderDetails SearchDetails(int oId)
       {
           Invoice_OrderDetails order = null;

           try
           {
               order = Invoice_OrderDetailsDAL.SearchDetails(oId);
           }
           catch (Invoice_OrderDetailsExceptions ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return order;
       }

       public static List<Invoice_OrderDetails> DisplayDetails()
       {
           List<Invoice_OrderDetails> ordList = null;

           try
           {
               ordList = Invoice_OrderDetailsDAL.DisplayDetails();
           }
           catch (Invoice_OrderDetailsExceptions ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return ordList;
       }
       public List<Invoice_OrderDetails> GetAll()
       {
           return dal.SelectAll();
       }
    }
}
