﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.Entity;
using OIMS.Exceptions;
using OIMS.BL;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for ManProdInfo.xaml
    /// </summary>
    public partial class ManProdInfo : Window
    {
        Invoice_ProductBL bal = null;
        List<Invoice_Product> prodList = null;
        public ManProdInfo()
        {
            InitializeComponent(); 
            prodList = new List<Invoice_Product>();
            bal = new Invoice_ProductBL();
            prodList = bal.GetAll();
            dgProduct.ItemsSource = prodList;


            cbProdID.ItemsSource = prodList;
            cbProdID.DisplayMemberPath = "ProductId";
        }
        
        
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Invoice_Product prod = new Invoice_Product();
                prod.ProductName = txtProdName.Text;
                prod.UnitType = txtUnitType.Text;
                prod.Price = Convert.ToInt32(txtPrice.Text);
                prod.CategoryId = Convert.ToInt32(txtProdCatId.Text);
                prod.Description = txtDescription.Text;

                if (Invoice_ProductBL.InsertProduct(prod) > 0)
                {
                    MessageBox.Show("Product Information Inserted!");
                    //List<Invoice_Category> catList = new List<Invoice_Category>();
                    prodList = bal.GetAll();
                    dgProduct.ItemsSource = prodList;
                    dgProduct.DataContext = prodList;


                    cbProdID.ItemsSource = prodList;
                    cbProdID.DisplayMemberPath = "ProductId";
                }



            }
            catch (Invoice_ProductExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Product prod = new Invoice_Product();

                if (int.TryParse(cbProdID.Text, out id))
                {
                    prod.ProductId = id;
                    prod.ProductName = txtProdName.Text;
                    prod.UnitType = txtUnitType.Text;
                    prod.Price = Convert.ToInt32(txtPrice.Text);
                    prod.CategoryId = Convert.ToInt32(txtProdCatId.Text);
                    prod.Description = txtDescription.Text;

                }



                if (Invoice_ProductBL.UpdateProduct(prod) > 0)
                {
                    MessageBox.Show("Product information Updated!");


                    prodList = bal.GetAll();
                    dgProduct.ItemsSource = prodList;
                }
            }
            catch (Invoice_ProductExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Product prod = new Invoice_Product();

                if (int.TryParse(cbProdID.Text, out id))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }



                if (Invoice_ProductBL.DeleteProduct(id) > 0)
                {
                    MessageBox.Show("Product Information Deleted!");
                    //cbCatID.Text = null;

                    prodList = bal.GetAll();
                    dgProduct.ItemsSource = prodList;

                    cbProdID.ItemsSource = prodList;
                    cbProdID.DisplayMemberPath = "ProductId";

                }


            }
            catch (Invoice_ProductExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
