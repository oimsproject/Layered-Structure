﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for GenerateInvoice.xaml
    /// </summary>
    public partial class GenerateInvoice : Window
    {
         Invoice_InvoiceBL bal = null;
        List<Invoice_Invoice> iList = null;
            
        public GenerateInvoice()
        {
        
            InitializeComponent();
            iList = new List<Invoice_Invoice>();
            bal = new Invoice_InvoiceBL();
            iList = bal.GetAll();
            dgGen.ItemsSource = iList;


            cbInvoiceID.ItemsSource = iList;
            cbInvoiceID.DisplayMemberPath = "InvoiceId";
        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                bal = new Invoice_InvoiceBL();
                Invoice_Invoice inv = new Invoice_Invoice();

                
                inv.InvoiceId = Convert.ToInt32(cbInvoiceID.Text);
                inv.InvoiceDate = Convert.ToDateTime(dpInvoiceDate.Text);
                inv.OrderId = Convert.ToInt32(txtOrderID.Text);



                if (Invoice_InvoiceBL.InsertInvoice(inv) > 0)
                {
                    MessageBox.Show("Invoice Generated!");

                    iList = bal.GetAll();
                    dgGen.ItemsSource = iList;
                    dgGen.DataContext = iList;


                    cbInvoiceID.ItemsSource = iList;
                    cbInvoiceID.DisplayMemberPath = "InvoiceId";
                }



            }
            catch (Invoice_InvoiceExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
