﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.DAL
{
    public class Invoice_UsersDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Invoice_UsersDAL()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;

            cn = new SqlConnection(cnStr);
        }
        public List<Invoice_Users> SelectAll()
        {
            List<Invoice_Users> userList = new List<Invoice_Users>();

            try
            {
                cmd = new SqlCommand("USP_Display_Users_OIMS", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Users user = new Invoice_Users();
                    user.ID = Convert.ToInt32(dr[0]);
                    user.Username = dr[1].ToString();
                    user.Password = dr[2].ToString();
                    user.Status = dr[3].ToString();
                   

                    userList.Add(user);

                }
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return userList;
        }


        public static int InsertUsers(Invoice_Users users)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Users_OIMS";

                cmd.Parameters.AddWithValue("@IDP", users.ID);
                cmd.Parameters.AddWithValue("@UsernameP", users.Username);
                cmd.Parameters.AddWithValue("@PasswordP", users.Password);
                cmd.Parameters.AddWithValue("@StatusP", users.Status);
               

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

                

            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateUsers(Invoice_Users users)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Users_OIMS";

                cmd.Parameters.AddWithValue("@IDP", users.ID);
                cmd.Parameters.AddWithValue("@UsernameP", users.Username);
                cmd.Parameters.AddWithValue("@PasswordP", users.Password);
                cmd.Parameters.AddWithValue("@StatusP", users.Status);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteUsers(int uId)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Users_OIMS";

                cmd.Parameters.AddWithValue("@IDP",uId);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Users SearchUsers(int uId)
        {
            Invoice_Users users = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Search_Users_OIMS";

                cmd.Parameters.AddWithValue("@IDP", uId);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    users = new Invoice_Users();
                    users.ID = Convert.ToInt32((dr["ID"]).ToString());
                    users.Username = (dr["Username"]).ToString();
                    users.Password = dr["Password"].ToString();
                    users.Status = (dr["Status"]).ToString();
                   
                }
                else
                {
                    throw new Invoice_UsersExceptions("User is not avaialble with code : " + uId);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return users;
        }

         public static List<Invoice_Users> DisplayUsers()
        {
            List<Invoice_Users> usersList = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Display_Users_OIMS";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    usersList = new List<Invoice_Users>();

                    while (dr.Read())
                    {
                        Invoice_Users users = new Invoice_Users();
                    
                        users.ID = Convert.ToInt32(dr["ID"]);
                        users.Username = dr["Username"].ToString();
                        users.Password = (dr["Password"].ToString());
                        users.Status = (dr["Status"].ToString());
                       

                        usersList.Add(users);
                    }
                }
                else
                    throw new Invoice_UsersExceptions("Users Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return usersList;
        }

    }
    }

