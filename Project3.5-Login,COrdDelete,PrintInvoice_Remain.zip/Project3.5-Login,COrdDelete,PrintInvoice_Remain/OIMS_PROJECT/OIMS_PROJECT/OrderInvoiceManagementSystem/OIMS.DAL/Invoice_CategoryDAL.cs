﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.DAL
{
    public class Invoice_CategoryDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Invoice_CategoryDAL()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;

            cn = new SqlConnection(cnStr);
        }
        public List<Invoice_Category> SelectAll()
        {
            List<Invoice_Category> catList = new List<Invoice_Category>();

            try
            {
                cmd = new SqlCommand("USP_Display_Category_OIMS", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Category cat = new Invoice_Category();
                    cat.CategoryId = Convert.ToInt32(dr[0]);
                    cat.CategoryName = dr[1].ToString();
                    cat.Description = dr[2].ToString();
              
                    catList.Add(cat);

                }
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return catList;
        }

        public int InsertCategory(Invoice_Category cat)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Category_OIMS";

                cmd.Parameters.AddWithValue("@CategoryIdP", cat.CategoryId);
                cmd.Parameters.AddWithValue("@CategoryNameP", cat.CategoryName);

                cmd.Parameters.AddWithValue("@DescriptionP", cat.Description);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateCategory(Invoice_Category cat)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Category_OIMS";

                cmd.Parameters.AddWithValue("@CategoryIdP", cat.CategoryId);
                cmd.Parameters.AddWithValue("@CategoryNameP", cat.CategoryName);

                cmd.Parameters.AddWithValue("@DescriptionP", cat.Description);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteCategory(int cid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Category_OIMS";

                cmd.Parameters.AddWithValue("@CategoryIdP", cid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Category SearchCategory(int cid)
        {
            Invoice_Category cat = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Search_Category_OIMS";

                cmd.Parameters.AddWithValue("@CategoryIdP", cid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    cat = new Invoice_Category();
                    cat.CategoryId = Convert.ToInt32(dr["CategoryId"]);
                    cat.CategoryName = dr["CategoryName"].ToString();

                    cat.Description = dr["Description"].ToString();
                }
                else
                {
                    throw new Invoice_CategoryExceptions("Category not avaialble with code : " + cid);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cat;
        }

        public static List<Invoice_Category> DisplayCategory()
        {
            List<Invoice_Category> catList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    catList = new List<Invoice_Category>();

                    while (dr.Read())
                    {
                        Invoice_Category cat = new Invoice_Category();
                        cat.CategoryId = Convert.ToInt32(dr["CategoryId"]);
                        cat.CategoryName = dr["CategoryName"].ToString();

                        cat.Description = dr["Description"].ToString();


                        catList.Add(cat);
                    }
                }
                else
                    throw new Invoice_CategoryExceptions("Student Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return catList;
        }
    }
}
