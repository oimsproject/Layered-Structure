﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS.Exceptions
{
   public class Invoice_OrderExceptions:ApplicationException
    {
        public Invoice_OrderExceptions()
        {

        }
        public Invoice_OrderExceptions(string message)
            : base(message)
        {

        }
    }
}
