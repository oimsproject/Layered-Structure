﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS.Exceptions
{
    public class Invoice_CategoryExceptions:ApplicationException
    {
           public Invoice_CategoryExceptions()
        {

        }
        public Invoice_CategoryExceptions(string message)
            : base(message)
        {

        }
    
    }
}
