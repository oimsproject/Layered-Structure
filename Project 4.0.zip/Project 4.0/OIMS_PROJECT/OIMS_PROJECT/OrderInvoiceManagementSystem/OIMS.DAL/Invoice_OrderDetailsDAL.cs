﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.DAL
{
        
   public class Invoice_OrderDetailsDAL
   {
       SqlConnection cn = null;
       SqlCommand cmd = null;
       SqlDataReader dr = null;

        public Invoice_OrderDetailsDAL()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;

            cn = new SqlConnection(cnStr);
        }
        
        public static int InsertDetails(Invoice_OrderDetails ordet)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_OrderDetails_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", ordet.OrderId);
                cmd.Parameters.AddWithValue("@ProductIdP", ordet.ProductId);
                cmd.Parameters.AddWithValue("@UnitPriceP ", ordet.UnitPrice);
                cmd.Parameters.AddWithValue("@QuantityP ", ordet.Quantity);


                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateDetails(Invoice_OrderDetails ordet)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_OrderDetails_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", ordet.OrderId);
                cmd.Parameters.AddWithValue("@ProductIdP", ordet.ProductId);
                cmd.Parameters.AddWithValue("@UnitPriceP ", ordet.UnitPrice);
                cmd.Parameters.AddWithValue("@QuantityP ", ordet.Quantity);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteDetails(int OrderId, int ProductId)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_OrderDetails_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", OrderId);
                cmd.Parameters.AddWithValue("@ProductIdP", ProductId);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_OrderDetails SearchDetails(int ProductId)
        {
            Invoice_OrderDetails ordet = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Search_OrderDetails_OIMS";

                cmd.Parameters.AddWithValue("@ProductIdP", ProductId);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    ordet = new Invoice_OrderDetails();
                   // ordet.OrderId = Convert.ToInt32(dr["OrderId"]);
                   ordet.ProductId = Convert.ToInt32(dr["ProductId"]);
                    ordet.UnitPrice = Convert.ToInt32(dr["UnitPrice"]);
                   // ordet.Quantity = Convert.ToInt32(dr["Quantity"]);

                }
                else
                {
                    throw new Invoice_OrderDetailsExceptions("Price not avaialble with ID : " + ProductId);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ordet;
        }

        public static List<Invoice_OrderDetails> DisplayDetails()
        {
            List<Invoice_OrderDetails> OrdetList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Display_OrderDetails_OIMS";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    OrdetList = new List<Invoice_OrderDetails>();

                    while (dr.Read())
                    {
                        Invoice_OrderDetails ordet = new Invoice_OrderDetails();

                        ordet.OrderId = Convert.ToInt32(dr["OrderId"]);
                        ordet.ProductId = Convert.ToInt32(dr["ProductId"]);
                        ordet.UnitPrice = Convert.ToInt32(dr["UnitPrice"]);
                        ordet.Quantity = Convert.ToInt32(dr["Quantity"]);


                        OrdetList.Add(ordet);
                    }
                }
                else
                    throw new Invoice_OrderDetailsExceptions("Order Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return OrdetList;
        }

        public List<Invoice_OrderDetails> SelectAll()
        {
            List<Invoice_OrderDetails> ordList = new List<Invoice_OrderDetails>();

            try
            {
                cmd = new SqlCommand("USP_Display_OrderDetails_OIMS", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_OrderDetails ord = new Invoice_OrderDetails();
                    ord.OrderId = Convert.ToInt32(dr[0]);
                    ord.ProductId = Convert.ToInt32(dr[1]);
                    ord.Quantity = Convert.ToInt32(dr[2]);
                    ord.UnitPrice = Convert.ToInt32(dr[3]);

                    ordList.Add(ord);

                }
            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return ordList;
        }
    }
}
