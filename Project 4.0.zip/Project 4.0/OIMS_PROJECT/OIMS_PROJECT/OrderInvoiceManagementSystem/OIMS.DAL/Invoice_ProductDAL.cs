﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.DAL
{
    public class Invoice_ProductDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Invoice_ProductDAL()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;

            cn = new SqlConnection(cnStr);
        }
        public List<Invoice_Product> SelectAll()
        {
            List<Invoice_Product> prodList = new List<Invoice_Product>();

            try
            {
                cmd = new SqlCommand("USP_Display_Product_OIMS", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Product prod = new Invoice_Product();
                    prod.ProductId = Convert.ToInt32(dr[0]);
                    prod.ProductName = dr[1].ToString();
                    prod.UnitType = dr[2].ToString();
                    prod.Price = Convert.ToInt32(dr[3]);
                    prod.CategoryId = Convert.ToInt32(dr[4]);
                    prod.Description = dr[5].ToString(); ;

                    prodList.Add(prod);

                }
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return prodList;
        }
        
        public static int InsertProduct(Invoice_Product prod)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Insert_Product_OIMS";

                cmd.Parameters.AddWithValue("@ProductIdP", prod.ProductId);
                cmd.Parameters.AddWithValue("@ProductNameP", prod.ProductName);
                cmd.Parameters.AddWithValue("@UnitTypeP", prod.UnitType);
                cmd.Parameters.AddWithValue("@PriceP", prod.Price);
                cmd.Parameters.AddWithValue("@CategoryIdP", prod.CategoryId);
                cmd.Parameters.AddWithValue("@DescriptionP", prod.Description);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateProduct(Invoice_Product prod)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Update_Product_OIMS";

                cmd.Parameters.AddWithValue("@ProductIdP", prod.ProductId);
                cmd.Parameters.AddWithValue("@ProductNameP", prod.ProductName);
                cmd.Parameters.AddWithValue("@UnitTypeP", prod.UnitType);
                cmd.Parameters.AddWithValue("@PriceP", prod.Price);
                cmd.Parameters.AddWithValue("@CategoryIdP", prod.CategoryId);
                cmd.Parameters.AddWithValue("@DescriptionP", prod.Description);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteProduct(int pid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Delete_Product_OIMS";

                cmd.Parameters.AddWithValue("@ProductIdP", pid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Product SearchProduct(int pid)
        {
            Invoice_Product prod = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Search_Product_OIMS";

                cmd.Parameters.AddWithValue("@ProductIdP", pid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    prod = new Invoice_Product();
                    prod.ProductId = Convert.ToInt32(dr["ProductId"]);
                    prod.ProductName = dr["ProductName"].ToString();
                    prod.UnitType = dr["UnitType"].ToString();
                    prod.Price = Convert.ToInt32(dr["Price"]);
                    prod.CategoryId = Convert.ToInt32(dr["CategoryId"]);
                    prod.Description = dr["Description"].ToString();
                }
                else
                {
                    throw new Invoice_ProductExceptions("Product not avaialble with ID : " + pid);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prod;
        }
        public static List<Invoice_Product> DisplayProduct()
        {
            List<Invoice_Product> prodList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Display_Product_OIMS";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    prodList = new List<Invoice_Product>();

                    while (dr.Read())
                    {
                        Invoice_Product prod = new Invoice_Product();

                        prod.ProductId = Convert.ToInt32(dr["ProductId"]);
                        prod.ProductName = dr["ProductName"].ToString();
                        prod.UnitType = dr["UnitType"].ToString();
                        prod.Price = Convert.ToInt32(dr["Price"]);
                        prod.CategoryId = Convert.ToInt32(dr["CategoryId"]);
                        prod.Description = dr["Description"].ToString();



                        prodList.Add(prod);
                    }
                }
                else
                    throw new Invoice_ProductExceptions("Product Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }
    }
}
