﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for OMISLogin.xaml
    /// </summary>
    public partial class OMISLogin : Window
    {
        Invoice_UsersBL userbl = new Invoice_UsersBL();
        Invoice_Users user = new Invoice_Users();
        List<Invoice_Users> userlist = new List<Invoice_Users>();
        public OMISLogin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string user = txtUserID.Text;
            string pwd = Pass.Password;

            int a = 0;
            userlist = userbl.GetAll();

           
            
                foreach (var k in userlist)
                {
                    if (k.Username == user && k.Password == pwd)
                    {
                        a=a+1;
                        if (k.Status == "Administrator" && rbtnAdmin.IsChecked == true)
                        {
                            
                            WelAdmin weladmin = new WelAdmin();
                            weladmin.Show();
                            this.Close();
                        }

                        else if (k.Status == "Clerk" && rbtnClerk.IsChecked == true)
                        {
                          
                            WelClerk welclerk = new WelClerk();
                            welclerk.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Select Valid User Type");
                        }

                        break;
                    }

                
                }
            if(a==0)
            {
                MessageBox.Show("Enter valid User Name / Password");
            }

                    
	          }
            }

            //if (rbtnAdmin.IsChecked == true)
            //{
            //    WelAdmin weladmin = new WelAdmin();
            //    weladmin.Show();
            //    this.Close();
            //}
            //else if (rbtnClerk.IsChecked == true)
            //{
            //    WelClerk welclerk = new WelClerk();
            //    welclerk.Show();
            //    this.Close();
            //}
        }

