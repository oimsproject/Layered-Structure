﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.Entity;
using OIMS.Exceptions;
using OIMS.BL;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for ManCustInfo.xaml
    /// </summary>
    public partial class ManCustInfo : Window
    {
        Invoice_CustomerBL bal = null;
        List<Invoice_Customer> custList = null;
        public ManCustInfo()
        {
            InitializeComponent(); 
            custList = new List<Invoice_Customer>();
            bal = new Invoice_CustomerBL();
            custList = bal.GetAll();
            dgCustInfo.ItemsSource = custList;


            cbCustID.ItemsSource = custList;
            cbCustID.DisplayMemberPath = "CustomerId";
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Invoice_Customer cust = new Invoice_Customer();
                cust.CustomerName = txtCustName.Text;
                cust.Contact = txtContactNo.Text;
                cust.Email = txtEmail.Text;
                cust.Address = txtAddress.Text;
                cust.City = txtCity.Text;
                cust.Pincode = txtPincode.Text;

                if (Invoice_CustomerBL.InsertCustomer(cust) > 0)
                {
                    MessageBox.Show("Customer Information Inserted!");
                    //List<Invoice_Category> catList = new List<Invoice_Category>();
                    custList = bal.GetAll();
                    dgCustInfo.ItemsSource = custList;
                    dgCustInfo.DataContext = custList;


                    cbCustID.ItemsSource = custList;
                    cbCustID.DisplayMemberPath = "CustomerId";
                }



            }
            catch (Invoice_CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Customer cust = new Invoice_Customer();

                if (int.TryParse(cbCustID.Text, out id))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }



                if (Invoice_CustomerBL.DeleteCustomer(id) > 0)
                {
                    MessageBox.Show("Customer Information Deleted!");
                    //cbCatID.Text = null;

                    custList = bal.GetAll();
                    dgCustInfo.ItemsSource = custList;

                    cbCustID.ItemsSource = custList;
                    cbCustID.DisplayMemberPath = "CustomerId";

                }


            }
            catch (Invoice_CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Customer cat = new Invoice_Customer();

                if (int.TryParse(cbCustID.Text, out id))
                {
                    cat.CustomerId = id;
                    cat.CustomerName = txtCustName.Text;
                    cat.Contact = txtContactNo.Text;
                    cat.Email = txtEmail.Text;
                    cat.Address = txtAddress.Text;
                    cat.City = txtCity.Text;
                    cat.Pincode = txtPincode.Text;

                }



                if (Invoice_CustomerBL.UpdateCustomer(cat) > 0)
                {
                    MessageBox.Show("Customer information Updated!");


                    custList = bal.GetAll();
                    dgCustInfo.ItemsSource = custList;
                }
            }
            catch (Invoice_CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
