﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for WelAdmin.xaml
    /// </summary>
    public partial class WelAdmin : Window
    {
        public WelAdmin()
        {
            InitializeComponent();
        }

        private void btnManCategoryInfo_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<ManCategoryInfo>().Any())
            {
                Application.Current.Windows.OfType<ManCategoryInfo>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new ManCategoryInfo().Show();
            }
            
        }

        private void btnManCustInfo_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<ManCustInfo>().Any())
            {
                Application.Current.Windows.OfType<ManCustInfo>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new ManCustInfo().Show();
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            OMISLogin oimsLogin = new OMISLogin();
            oimsLogin.Show();
            this.Close();
        }

        private void btnManProdInfo_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<ManProdInfo>().Any())
            {
                Application.Current.Windows.OfType<ManProdInfo>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new ManProdInfo().Show();
            }
        }

        private void btnManUserInfo_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<ManUserInfo>().Any())
            {
                Application.Current.Windows.OfType<ManUserInfo>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new ManUserInfo().Show();
            }
        }

        private void btnGenReport_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<GenerateReport>().Any())
            {
                Application.Current.Windows.OfType<GenerateReport>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new GenerateReport().Show();
            }
        }
    }
}
