﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.Entity;
using OIMS.Exceptions;
using OIMS.BL;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for UpdateOrderDetails.xaml
    /// </summary>
    public partial class UpdateOrderDetails : Window
    {
        Invoive_OrderBL bal = null;
        Invoice_OrderDetailsBL dbal = null;
        Invoice_ProductBL pbal = null;
        List<Invoice_Order> ordList = null;
        List<Invoice_Product> prodList = null;
        List<Invoice_OrderDetails> dordList = null;


        public UpdateOrderDetails()
        {
            InitializeComponent();
            ordList = new List<Invoice_Order>();
            prodList = new List<Invoice_Product>();
            dordList = new List<Invoice_OrderDetails>();
            bal = new Invoive_OrderBL();
            pbal = new Invoice_ProductBL();
            dbal = new Invoice_OrderDetailsBL();
            ordList = bal.GetAll();
            prodList = pbal.GetAll();
            dordList = dbal.GetAll();
            dgUpdateOrderDetails.ItemsSource = dordList;


            cbOrdId.ItemsSource = ordList;
            cbOrdId.DisplayMemberPath = "OrderId";
            cbProdId.ItemsSource = prodList;
            cbProdId.DisplayMemberPath = "ProductId";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

   

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_OrderDetails ord = new Invoice_OrderDetails();

                if (int.TryParse(cbOrdId.Text, out id))
                {
                    ord.OrderId = id;
                    ord.ProductId = Convert.ToInt32(cbProdId.Text);
                    ord.UnitPrice = Convert.ToInt32(txtUnitPrice.Text);
                    ord.Quantity = Convert.ToInt32(txtQuant.Text);
                }



                if (Invoice_OrderDetailsBL.UpdateDetails(ord) > 0)
                {
                    MessageBox.Show("Order Details Updated!");


                    dordList = dbal.GetAll();
                    dgUpdateOrderDetails.ItemsSource = dordList;
                    dgUpdateOrderDetails.DataContext = dordList;


                    cbOrdId.ItemsSource = ordList;
                    cbOrdId.DisplayMemberPath = "OrderId";
                    cbProdId.ItemsSource = prodList;
                    cbProdId.DisplayMemberPath = "ProductId";
                }

            }
            catch (Invoice_OrderDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        
    }
}
