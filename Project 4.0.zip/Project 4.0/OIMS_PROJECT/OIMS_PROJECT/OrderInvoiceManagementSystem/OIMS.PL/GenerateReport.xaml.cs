﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for GenerateReport.xaml
    /// </summary>
    public partial class GenerateReport : Window
    {
        Training_13Dec17_Hinjawadi_PuneEntities dbcontext = null;
        public GenerateReport()
        {
            InitializeComponent();
            dbcontext = new Training_13Dec17_Hinjawadi_PuneEntities();
        }

        private void Report_Click(object sender, RoutedEventArgs e)
        {
            DateTime k = Convert.ToDateTime(dpFrom.Text);
            DateTime j = Convert.ToDateTime(dpTo.Text);
            var res = from p in dbcontext.Order_OIMS
                      where p.OrderDate >= k && p.OrderDate <= j
                      select p;



            dgReport.ItemsSource = res.ToList();
        }

        private void Sum_Click(object sender, RoutedEventArgs e)
        {
            DateTime k = Convert.ToDateTime(dpFrom.Text);
            DateTime j = Convert.ToDateTime(dpTo.Text);
            var total = (from p in dbcontext.Order_OIMS
                         where p.OrderDate >= k && p.OrderDate <= j
                         select p.Amount).Sum();
            txtSum.Text = Convert.ToString(total);

        }
    }
}
