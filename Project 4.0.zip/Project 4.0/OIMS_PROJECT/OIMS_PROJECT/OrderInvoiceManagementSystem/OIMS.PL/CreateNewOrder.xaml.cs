﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for CreateNewOrder.xaml
    /// </summary>
    public partial class CreateNewOrder : Window
    {
        Invoive_OrderBL bal = null;
        List<Invoice_Order> ordList = null;
        Invoice_CustomerBL custbal = null;
        List<Invoice_Customer> custList = null;
        public CreateNewOrder()
        {
            InitializeComponent();
            ordList = new List<Invoice_Order>();
            bal = new Invoive_OrderBL();
            custList = new List<Invoice_Customer>();
            custbal = new Invoice_CustomerBL();
            custList = custbal.GetAll();
            ordList = bal.GetAll();
            dgOrder.ItemsSource = ordList;


            cbOrdID.ItemsSource = ordList;
            cbOrdID.DisplayMemberPath = "OrderId";
            cbCustID.ItemsSource = custList;
            cbCustID.DisplayMemberPath = "CustomerId";
            
        }

       

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void bntInsertDetails_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<CreateOrderDetails>().Any())
            {
                Application.Current.Windows.OfType<CreateOrderDetails>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new CreateOrderDetails().Show();
                this.Close();
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                bal = new Invoive_OrderBL();
                Invoice_Order ord = new Invoice_Order();

               // ord.OrderId = Convert.ToInt32(cbOrdID.Text);
                ord.OrderDate =Convert.ToDateTime(dpOrdDate.Text);
                ord.CustomerId = Convert.ToInt32(cbCustID.Text);
                ord.Amount = Convert.ToInt32(txtAmount.Text);



                if (Invoive_OrderBL.InsertOrder(ord) > 0)
                {
                    MessageBox.Show("Order Created!");
                   
                    ordList = bal.GetAll();
                    dgOrder.ItemsSource = ordList;
                    dgOrder.DataContext = ordList;


                    cbOrdID.ItemsSource = ordList;
                    cbOrdID.DisplayMemberPath = "OrderId";
                    cbCustID.ItemsSource = custList;
                    cbCustID.DisplayMemberPath = "CustomerId";
                }



            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
