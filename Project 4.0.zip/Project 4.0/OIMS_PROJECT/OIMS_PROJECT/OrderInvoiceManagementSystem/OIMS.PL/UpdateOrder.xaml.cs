﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for UpdateOrder.xaml
    /// </summary>
    public partial class UpdateOrder : Window
    {
        Invoive_OrderBL bal = null;
        Invoice_CustomerBL custbal = null;
        List<Invoice_Order> ordList = null;
        List<Invoice_Customer> custList = null;
        public UpdateOrder()
        {
            InitializeComponent();
            ordList = new List<Invoice_Order>();
            custList = new List<Invoice_Customer>();
            bal = new Invoive_OrderBL();
            custbal = new Invoice_CustomerBL();
            ordList = bal.GetAll();
            custList = custbal.GetAll();
            dgOrder.ItemsSource = ordList;


            cbOrdID.ItemsSource = ordList;
            cbOrdID.DisplayMemberPath = "OrderId";
            cbCustID.ItemsSource = custList;
            cbCustID.DisplayMemberPath = "CustomerId";
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Order ord = new Invoice_Order();

                if (int.TryParse(cbOrdID.Text, out id))
                {
                    ord.OrderId = id;
                    ord.OrderDate = Convert.ToDateTime(dpOrdDate.Text);
                    ord.CustomerId = Convert.ToInt32(cbCustID.Text);
                    ord.Amount = Convert.ToInt32(txtAmount.Text);
                }



                if (Invoive_OrderBL.UpdateOrder(ord) > 0)
                {
                    MessageBox.Show("Order Updated!");


                    ordList = bal.GetAll();
                    dgOrder.ItemsSource = ordList;
                    cbCustID.ItemsSource = custList;
                    cbCustID.DisplayMemberPath = "CustomerId";

                }

            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
