﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.Entity;
using OIMS.Exceptions;
using OIMS.BL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for PrintInvoice.xaml
    /// </summary>
    public partial class PrintInvoice : Window
    {
        Training_13Dec17_Hinjawadi_PuneEntities context = new Training_13Dec17_Hinjawadi_PuneEntities();
        Training_13Dec17_Hinjawadi_PuneEntities1 context2 = new Training_13Dec17_Hinjawadi_PuneEntities1();
        Invoice_InvoiceBL ibl = null;
        List<Invoice_Invoice> ilist = null;


        public PrintInvoice()
        {
            InitializeComponent();
            ibl = new Invoice_InvoiceBL();
            ilist = new List<Invoice_Invoice>();
            ilist = ibl.GetAll();
            cbInvID.ItemsSource = ilist;
            cbInvID.DisplayMemberPath = "InvoiceId";
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            var printT = (from x in context2.OrderDetails_OIMS
                          join y in context2.Invoice_OIMS on x.OrderId equals y.OrderId into ps
                          from p in ps
                          select new { x.ProductId, x.OrderId, x.Quantity, x.UnitPrice, Total = x.UnitPrice * x.Quantity }).ToList();

            dgPrint.ItemsSource = printT;
    
      }  
       
          



}
            



           
       }
          
 
 
