﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.BL;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for DeleteOrder.xaml
    /// </summary>
    public partial class DeleteOrder : Window
    {
        Invoive_OrderBL bal = null;
        List<Invoice_Order> ordList = null;
        public DeleteOrder()
        {
            InitializeComponent();
            ordList = new List<Invoice_Order>();
            bal = new Invoive_OrderBL();
            ordList = bal.GetAll();
            dgOrder.ItemsSource = ordList;


            cbOrdID.ItemsSource = ordList;
            cbOrdID.DisplayMemberPath = "OrderId";
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                //Invoice_Category cat = new Invoice_Category();

                if (int.TryParse(cbOrdID.Text, out id))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }



                if (Invoive_OrderBL.DeleteOrder(id) > 0)
                {
                    MessageBox.Show("Order Deleted!");
                    //cbCatID.Text = null;

                    ordList = bal.GetAll();
                    dgOrder.ItemsSource = ordList;

                    cbOrdID.ItemsSource = ordList;
                    cbOrdID.DisplayMemberPath = "OrderId";

                }


            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
