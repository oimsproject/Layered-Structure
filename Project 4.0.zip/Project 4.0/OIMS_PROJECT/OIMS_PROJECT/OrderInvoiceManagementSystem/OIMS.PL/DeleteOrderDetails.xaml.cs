﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.Entity;
using OIMS.Exceptions;
using OIMS.BL;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for DeleteOrderDetails.xaml
    /// </summary>
    public partial class DeleteOrderDetails : Window
    {
        Invoice_OrderDetailsBL orddbal = null;
        Invoice_ProductBL prodbal = null;
        List<Invoice_OrderDetails> ordList = null;
        List<Invoice_Product> prodList = null;
        public DeleteOrderDetails()
        {
            InitializeComponent();
            orddbal = new Invoice_OrderDetailsBL();
            prodbal = new Invoice_ProductBL();
            ordList = new List<Invoice_OrderDetails>();
            prodList = new List<Invoice_Product>();
            ordList = orddbal.GetAll();
            prodList = prodbal.GetAll();

            dgDelete.ItemsSource = ordList;
            cbOrdId.ItemsSource = ordList;
            cbOrdId.DisplayMemberPath = "OrderId";

            cbProdId.ItemsSource = ordList;
            cbProdId.DisplayMemberPath = "ProductId";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                int pid = 0;
                //Invoice_ cat = new Invoice_Category();

                if (int.TryParse(cbOrdId.Text, out id))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }
                if (int.TryParse(cbProdId.Text, out pid))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }


                if (Invoice_OrderDetailsBL.DeleteDetails(id,pid) > 0)
                {
                    MessageBox.Show("Order Details Deleted!");
                    //cbCatID.Text = null;

                    orddbal = new Invoice_OrderDetailsBL();
                    prodbal = new Invoice_ProductBL();
                    ordList = new List<Invoice_OrderDetails>();
                    prodList = new List<Invoice_Product>();
                    ordList = orddbal.GetAll();
                    prodList = prodbal.GetAll();

                   



                    dgDelete.ItemsSource = ordList;

                    
                    cbOrdId.ItemsSource = ordList;
                    cbOrdId.DisplayMemberPath = "OrderId";

                    cbProdId.ItemsSource = prodList;
                    cbProdId.DisplayMemberPath = "ProductId";

                }


            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
