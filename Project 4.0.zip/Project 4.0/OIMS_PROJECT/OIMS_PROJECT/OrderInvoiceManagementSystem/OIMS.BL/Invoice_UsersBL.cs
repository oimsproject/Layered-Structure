﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;


namespace OIMS.BL
{
    public class Invoice_UsersBL
    {
        Invoice_UsersDAL dal = null;
        public Invoice_UsersBL()
        {
            dal = new Invoice_UsersDAL();
        }
        public static bool ValildateUsers(Invoice_Users Iuser)
        {
            bool userValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (Iuser.Username.Trim() == String.Empty)
                {
                    userValidated = false;
                    message.Append("Username should be provided\n");
                }
                else if (!Regex.IsMatch(Iuser.Username, "^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$"))
                {
                    userValidated = false;
                    message.Append("Username should not have more than 1 separator. First and last character should not be a separator.");
                }
                if (Iuser.Password.Trim() == String.Empty)
                {
                    userValidated = false;
                    message.Append("Password should be provided\n");
                }
                else if (!Regex.IsMatch(Iuser.Password, "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$"))
                {
                    userValidated = false;
                    message.Append("Password should contain at least : 1 upper case letter, 1 lower case letter, 1 digit and 1 special character. Password should be of minnimum 8 characters.");
                }
                if (Iuser.Status.Trim() == String.Empty)
                {
                    userValidated = false;
                    message.Append("Status should not be empty");
                }
                else if (!Regex.IsMatch(Iuser.Status, "([A-Za-z])"))
                {
                    userValidated = false;
                    message.Append("Status should only contain alphabets.");
                }

                if (userValidated == false)
                    throw new Invoice_InvoiceExceptions(message.ToString());
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidated;
        }


        public List<Invoice_Users> GetAll()
        {
            return dal.SelectAll();
        }



        public static int InsertUsers(Invoice_Users user)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateUsers(user))
                {
                    recordsAffected = Invoice_UsersDAL.InsertUsers(user);
                }
                else
                    throw new Invoice_UsersExceptions("Please provide valid User Information");
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateUsers(Invoice_Users user)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateUsers(user))
                {
                    recordsAffected = Invoice_UsersDAL.UpdateUsers(user);
                }
                else
                    throw new Invoice_UsersExceptions("Please provide valid User Information");
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteUsers(int uid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_UsersDAL.DeleteUsers(uid);
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Users SearchUsers(int uid)
        {
            Invoice_Users user = null;

            try
            {
                user = Invoice_UsersDAL.SearchUsers(uid);
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }

        public static List<Invoice_Users> DisplayUsers()
        {
            List<Invoice_Users> uList = null;

            try
            {
                uList = Invoice_UsersDAL.DisplayUsers();
            }
            catch (Invoice_UsersExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return uList;
        }
    }
}
