﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;

namespace OIMS.BL
{
    public class Invoice_ProductBL
    {
        Invoice_ProductDAL dal = null;
        public Invoice_ProductBL()
        {
            dal = new Invoice_ProductDAL();
        }
        public static bool ValildateOrder(Invoice_Product prod)
        {
            bool prodValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (prod.ProductName.Trim() == string.Empty)
                {
                    prodValidated = false;
                    message.Append("Product Name should be provided and cannot be null\n");
                }

                else if (!Regex.IsMatch(prod.ProductName, "[A-Za-z]+"))
                {
                    message.Append("Product Name should have alphabets only\n");
                    prodValidated = false;
                }

                if (prod.UnitType.Trim() == string.Empty)
                {
                    prodValidated = false;
                    message.Append("UnitType should be provided and cannot be null\n");
                }

                if (prod.Price == 0)
                {
                    prodValidated = false;
                    message.Append("Product should be provided and cannot be null\n");
                }
                else if (prod.Price < 0)
                {
                    prodValidated = false;
                    message.Append("Product Price cannot be negative\n");

                }

                if (prod.Description.Trim() == string.Empty)
                {
                    prodValidated = false;
                    message.Append("Description should be provided \n");
                }
                else if (!Regex.IsMatch(prod.Description, "[A-Za-z]+"))
                {
                    prodValidated = false;
                    message.Append("Description should have alphabets only\n");
                }






                if (prodValidated == false)
                {
                    throw new Invoice_ProductExceptions(message.ToString());
                }
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodValidated;
        }

        public List<Invoice_Product> GetAll()
        {
            return dal.SelectAll();
        }



        public static int InsertProduct(Invoice_Product prod)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_ProductDAL.InsertProduct(prod);
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateProduct(Invoice_Product prod)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_ProductDAL.UpdateProduct(prod);
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteProduct(int pId)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_ProductDAL.DeleteProduct(pId);
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Product SearchProduct(int pId)
        {
            Invoice_Product prod = null;

            try
            {
                prod = Invoice_ProductDAL.SearchProduct(pId);
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prod;
        }

        public static List<Invoice_Product> DisplayProduct()
        {
            List<Invoice_Product> prodList = null;

            try
            {
                prodList = Invoice_ProductDAL.DisplayProduct();
            }
            catch (Invoice_ProductExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }
    }
}
