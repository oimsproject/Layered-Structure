﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;

namespace OIMS.BL
{
   public class Invoice_InvoiceBL
    {
       Invoice_InvoiceDAL dal = new Invoice_InvoiceDAL();
        public static bool ValidateInvoice(Invoice_Invoice inv)
        {
            bool invoiceValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (inv.OrderId <= 0)
                {
                    invoiceValidated = false;
                    message.Append("Order Id should be greater than 0\n");
                }

                if (inv.InvoiceDate == null)
                {
                    invoiceValidated = false;
                    message.Append("Invoice Date should be provided\n");
                }

                if (invoiceValidated == false)
                    throw new Invoice_InvoiceExceptions(message.ToString());
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return invoiceValidated;
        }

        public static int InsertInvoice(Invoice_Invoice inv)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateInvoice(inv))
                {
                    recordsAffected = Invoice_InvoiceDAL.InsertInvoice(inv);
                }
                else
                    throw new Invoice_InvoiceExceptions("Please provide valid Invoice Information");
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateInvoice(Invoice_Invoice inv)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateInvoice(inv))
                {
                    recordsAffected = Invoice_InvoiceDAL.UpdateInvoice(inv);
                }
                else
                    throw new Invoice_InvoiceExceptions("Please provide valid Student Information");
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteInvoice(int invId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_InvoiceDAL.DeleteInvoice(invId);
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Invoice SearchInvoice(int invId)
        {
            Invoice_Invoice inv = null;

            try
            {
                inv = Invoice_InvoiceDAL.SearchInvoice(invId);
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return inv;
        }

        public static List<Invoice_Invoice> DisplayInvoice()
        {
            List<Invoice_Invoice> invList = null;

            try
            {
                invList = Invoice_InvoiceDAL.DisplayInvoice();
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return invList;
        }

        public List<Invoice_Invoice> GetAll()
        {
            return dal.SelectAll();
        }
    }
}
