﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS.Exceptions
{
  public  class Invoice_ProductExceptions:ApplicationException
    {
        public Invoice_ProductExceptions()
        {

        }
        public Invoice_ProductExceptions(string message)
            : base(message)
        {

        }
    }
}
