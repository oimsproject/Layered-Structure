﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS.Exceptions
{
 public   class Invoice_InvoiceExceptions:ApplicationException
    {
        public Invoice_InvoiceExceptions()
        {

        }
        public Invoice_InvoiceExceptions(string message)
            : base(message)
        {

        }
    }
}
