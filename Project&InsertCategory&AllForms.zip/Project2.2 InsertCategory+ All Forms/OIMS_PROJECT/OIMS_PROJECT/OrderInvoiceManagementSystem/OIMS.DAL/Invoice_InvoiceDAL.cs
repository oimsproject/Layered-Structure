﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.DAL
{
    public class Invoice_InvoiceDAL
    {
        public static int InsertInvoice(Invoice_Invoice odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Invoice_OIMS";

                cmd.Parameters.AddWithValue("@InvoiceIdP", odr.InvoiceId);
                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@InvoiceDateP", odr.InvoiceDate);


                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateInvoice(Invoice_Invoice odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Invoice_OIMS";

                cmd.Parameters.AddWithValue("@InvoiceIdP", odr.InvoiceId);
                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@InvoiceDateP", odr.InvoiceDate);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteInvoice(int Inid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Invoice_OIMS";

                cmd.Parameters.AddWithValue("@InvoiceIdP", Inid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Invoice SearchInvoice(int Inid)
        {
            Invoice_Invoice odr = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Search_Invoice_OIMS";

                cmd.Parameters.AddWithValue("@InvoiceIdP", Inid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    odr = new Invoice_Invoice();
                    odr.InvoiceId = Convert.ToInt32(dr["InvoiceId"]);
                    odr.OrderId = Convert.ToInt32(dr["OrderId"]);
                    odr.InvoiceDate = Convert.ToDateTime(dr["InvoiceDate"]);

                }
                else
                {
                    throw new Invoice_InvoiceExceptions("Order not avaialble with ID : " + Inid);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return odr;
        }

        public static List<Invoice_Invoice> DisplayInvoice()
        {
            List<Invoice_Invoice> inList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    inList = new List<Invoice_Invoice>();

                    while (dr.Read())
                    {
                        Invoice_Invoice inOdr = new Invoice_Invoice();

                        inOdr.OrderId = Convert.ToInt32(dr["OrderId"]);
                        inOdr.InvoiceId = Convert.ToInt32(dr["InvoiceId"]);
                        inOdr.InvoiceDate = Convert.ToDateTime(dr["InvoiceDate"]);

                        inList.Add(inOdr);
                    }
                }
                else
                    throw new Invoice_OrderExceptions("Student Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return inList;
        }
    }
}
