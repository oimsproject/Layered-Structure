﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;


namespace OIMS.DAL
{
  public  class Invoice_OrderDAL
    {
        public static int InsertOrder(Invoice_Order odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Insert_Order_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@OrderDateP", odr.OrderDate);
                cmd.Parameters.AddWithValue("@CustomerIdP", odr.CustomerId);
                cmd.Parameters.AddWithValue("@AmountP", odr.Amount);


                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateOrder(Invoice_Order odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Update_Product_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@OrderDateP", odr.OrderDate);
                cmd.Parameters.AddWithValue("@CustomerIdP", odr.CustomerId);
                cmd.Parameters.AddWithValue("@AmountP", odr.Amount);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteOrder(int oid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Delete_Order_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", oid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Order SearchOrder(int oid)
        {
            Invoice_Order odr = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Search_Order_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", oid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    odr = new Invoice_Order();
                    odr.OrderId = Convert.ToInt32(dr["OrderId"]);
                    odr.OrderDate = Convert.ToDateTime(dr["OrderDate"]);
                    odr.CustomerId = Convert.ToInt32(dr["CustomerId"]);
                    odr.Amount = Convert.ToInt32(dr["Amount"]);

                }
                else
                {
                    throw new Invoice_OrderExceptions("Order not avaialble with ID : " + oid);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return odr;
        }

        public static List<Invoice_Order> DisplayOrder()
        {
            List<Invoice_Order> odrList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    odrList = new List<Invoice_Order>();

                    while (dr.Read())
                    {
                        Invoice_Order odr = new Invoice_Order();

                        odr.OrderId = Convert.ToInt32(dr["OrderId"]);
                        odr.OrderDate = Convert.ToDateTime(dr["OrderDate"]);
                        odr.CustomerId = Convert.ToInt32(dr["CustomerId"]);
                        odr.Amount = Convert.ToInt32(dr["Amount"]);



                        odrList.Add(odr);
                    }
                }
                else
                    throw new Invoice_OrderExceptions("Student Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return odrList;
        }
    }
}
