﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.DAL
{
    public class Invoice_CustomerDAL
    {
        public static int InsertCustomer(Invoice_Customer cust)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Customer_OIMS";

                cmd.Parameters.AddWithValue("@CustomerIdP", cust.CustomerId);
                cmd.Parameters.AddWithValue("@CustomerNameP", cust.CustomerName);
                cmd.Parameters.AddWithValue("@ContactP", cust.Contact);
                cmd.Parameters.AddWithValue("@EmailP", cust.Email);
                cmd.Parameters.AddWithValue("@AddressP", cust.Address);
                cmd.Parameters.AddWithValue("@CityP", cust.City);
                cmd.Parameters.AddWithValue("@PincodeP", cust.Pincode);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateCustomer(Invoice_Customer cust)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Customer_OIMS";

                cmd.Parameters.AddWithValue("@CustomerIdP", cust.CustomerId);
                cmd.Parameters.AddWithValue("@CustomerNameP", cust.CustomerName);
                cmd.Parameters.AddWithValue("@ContactP", cust.Contact);
                cmd.Parameters.AddWithValue("@EmailP", cust.Email);
                cmd.Parameters.AddWithValue("@AddressP", cust.Address);
                cmd.Parameters.AddWithValue("@CityP", cust.City);
                cmd.Parameters.AddWithValue("@PincodeP", cust.Pincode);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteCustomer(int cid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Customer_OIMS";

                cmd.Parameters.AddWithValue("@CustomerIdP", cid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Customer SearchCustomer(int cid)
        {
            Invoice_Customer cust = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Search_Customer_OIMS";

                cmd.Parameters.AddWithValue("@CustomerIdP", cid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    cust = new Invoice_Customer();
                    cust.CustomerId = Convert.ToInt32(dr["CustomerId"]);
                    cust.CustomerName = dr["CustomerName"].ToString();
                    cust.Contact = dr["Contact"].ToString();
                    cust.Email = dr["Email"].ToString();

                    cust.Address = dr["Addresses"].ToString();
                    cust.City = dr["City"].ToString();
                    cust.Pincode = dr["Pincode"].ToString();
                }
                else
                {
                    throw new Invoice_CustomerExceptions("Customer not available with given ID : " + cid);
                }
                cmd.Connection.Close();
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }

        public static List<Invoice_Customer> DisplayCustomer()
        {
            List<Invoice_Customer> custList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    custList = new List<Invoice_Customer>();

                    while (dr.Read())
                    {
                        Invoice_Customer cust = new Invoice_Customer();

                        cust.CustomerId = Convert.ToInt32(dr["CustomerId"]);
                        cust.CustomerName = dr["CustomerName"].ToString();
                        cust.Contact = dr["Contact"].ToString();
                        cust.Email = dr["Email"].ToString();

                        cust.Address = dr["Addresses"].ToString();
                        cust.City = dr["City"].ToString();
                        cust.Pincode = dr["Pincode"].ToString();

                        custList.Add(cust);
                    }
                }
                else
                    throw new Invoice_CustomerExceptions("Customer Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_CustomerExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custList;
        }
    }
}
