﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;


namespace OIMS.BL
{
    public class Invoice_CategoryBL
    {
        Invoice_CategoryDAL dal = null;
        public Invoice_CategoryBL()
        {
            dal = new Invoice_CategoryDAL();
        }
        public static bool ValidateCategory(Invoice_Category Icat)
        {
            bool CategoryValidated= true;
            StringBuilder message = new StringBuilder();

            try 
            {
                     if (Icat.CategoryName.Trim() == String.Empty)
                {
                    CategoryValidated = false;
                    message.Append("Category name should be provided\n");
                }
                else if (!Regex.IsMatch(Icat.CategoryName, "[A-Z][a-z]+"))
                {
                    CategoryValidated = false;
                    message.Append("Category name should have alphabets only and should start with Capital Letter \n");
                }

                if (Icat.Description.Trim() == String.Empty)
                {
                    CategoryValidated = false;
                    message.Append("Description Should be provided");
                }
                else if (!Regex.IsMatch(Icat.Description, "[A-Za-z]+"))
                {
                    CategoryValidated = false;
                    message.Append("Description should have alphabets only\n");
                }

                if (CategoryValidated == false)
                    throw new Invoice_CategoryExceptions(message.ToString());
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return CategoryValidated;
        }

        

        public List<Invoice_Category> GetAll()
        {
            return dal.SelectAll();
        }

        public static int InsertCategory(Invoice_Category Icat)
        {
            int recordsAffected = 0;

            try 
            {
                if (ValidateCategory(Icat))
                {
                    recordsAffected = InsertCategory(Icat);
                }
                else
                    throw new Invoice_CategoryExceptions("Please provide valid Category Information");
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateCategory(Invoice_Category Icat)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateCategory(Icat))
                {
                    recordsAffected = Invoice_CategoryDAL.UpdateCategory(Icat);
                }
                else
                    throw new Invoice_CategoryExceptions("Please provide valid Student Information");
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public bool Add(Invoice_Category cat)
        {
           bool categoryInserted = false;
           
            try
            {

                if (ValidateCategory(cat))
                {

                    dal.InsertCategory(cat);
                    categoryInserted = true;
                    

                }
                else
                    throw new Invoice_CategoryExceptions("Please Provide valid Category Details!");


            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }



            return categoryInserted;
        }

        public static int DeleteCategory(int catId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_CategoryDAL.DeleteCategory(catId);
            }
            catch(Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Category SearchCategory(int catId)
        {
            Invoice_Category cat = null;

            try
            {
                cat = Invoice_CategoryDAL.SearchCategory(catId);
            }
            catch(Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return cat;
        }

        public static List<Invoice_Category> DisplayCategory()
        {
            List<Invoice_Category> catList = null;

            try 
            {
                catList = Invoice_CategoryDAL.DisplayCategory();
            }
            catch (Invoice_CategoryExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return catList;
        }
    }
    }

