﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for ManCategoryInfo.xaml
    /// </summary>
    public partial class ManCategoryInfo : Window
    {
        Invoice_CategoryBL bal = null;
        public ManCategoryInfo()
        {
            InitializeComponent();
            bal = new Invoice_CategoryBL();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Invoice_Category cat = new Invoice_Category();
                cat.CategoryName = txtCatName.Text;

                cat.Description = txtCatDescription.Text;


                if (bal.Add(cat))
                {
                    MessageBox.Show("Category Inserted!");
                    List<Invoice_Category> catList = new List<Invoice_Category>();
                    catList = bal.GetAll();
                    dgCat.ItemsSource = catList;
                }


                
            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }
    }
}
