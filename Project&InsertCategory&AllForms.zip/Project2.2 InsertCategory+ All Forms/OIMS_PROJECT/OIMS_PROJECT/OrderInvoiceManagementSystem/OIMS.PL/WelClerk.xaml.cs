﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for WelClerk.xaml
    /// </summary>
    public partial class WelClerk : Window
    {
        public WelClerk()
        {
            InitializeComponent();
        }

        private void btnCreateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<CreateNewOrder>().Any())
            {
                Application.Current.Windows.OfType<CreateNewOrder>().First().Activate();

                MessageBox.Show("Window Already Open");
            }
            else
            {

                new CreateNewOrder().Show();

            }
        }

        private void btnUpdateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<UpdateOrder>().Any())
            {
                Application.Current.Windows.OfType<UpdateOrder>().First().Activate();

                MessageBox.Show("Windows Are Already Open");
            }
            else
            {

                new UpdateOrder().Show();

            }
        }

        private void btnUpdateOrderDetails_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<UpdateOrderDetails>().Any())
            {
                Application.Current.Windows.OfType<UpdateOrderDetails>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new UpdateOrderDetails().Show();
            }
        }

        private void btnDeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<DeleteOrderDetails>().Any())
            {
                Application.Current.Windows.OfType<DeleteOrderDetails>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new DeleteOrderDetails().Show();
            }
        }

        private void btnDeleteOrderDetais_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<DeleteOrderDetails>().Any())
            {
                Application.Current.Windows.OfType<DeleteOrderDetails>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new DeleteOrderDetails().Show();
            }
        }

        private void btnGenInvoice_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<GenerateInvoice>().Any())
            {
                Application.Current.Windows.OfType<GenerateInvoice>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new GenerateInvoice().Show();
            }
        }

        private void btnPrintInvoice_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<PrintInvoice>().Any())
            {
                Application.Current.Windows.OfType<PrintInvoice>().First().Activate();
                MessageBox.Show("Window Already Open");
            }
            else
            {
                new PrintInvoice().Show();
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            OMISLogin oimsLogin = new OMISLogin();
            oimsLogin.Show();
            this.Close();
        }
    }
}
