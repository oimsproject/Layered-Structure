﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for ManCategoryInfo.xaml
    /// </summary>
    public partial class ManCategoryInfo : Window
    {
        Invoice_CategoryBL bal = null;
        List<Invoice_Category> catList = null;

        public ManCategoryInfo()
        {
            InitializeComponent();
            catList = new List<Invoice_Category>();
            bal = new Invoice_CategoryBL();
            catList = bal.GetAll();
            dgCat.ItemsSource = catList;

           
            cbCatID.ItemsSource = catList;
            cbCatID.DisplayMemberPath = "CategoryId";
            
            


        }


        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Invoice_Category cat = new Invoice_Category();
                cat.CategoryName = txtCatName.Text;

                cat.Description = txtCatDescription.Text;




                if (bal.InsertCategory(cat) > 0)
                {
                    MessageBox.Show("Category Inserted!");
                    //List<Invoice_Category> catList = new List<Invoice_Category>();
                    catList = bal.GetAll();
                    dgCat.ItemsSource = catList;
                    dgCat.DataContext = catList;


                    cbCatID.ItemsSource = catList;
                    cbCatID.DisplayMemberPath = "CategoryId";
                }



            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {

                int id = 0;
                Invoice_Category cat = new Invoice_Category();

                if (int.TryParse(cbCatID.Text, out id))
                {
                    cat.CategoryId = id;
                    cat.CategoryName = txtCatName.Text;

                    cat.Description = txtCatDescription.Text;
                }



                if (Invoice_CategoryBL.UpdateCategory(cat) > 0)
                {
                    MessageBox.Show("Category Updated!");


                    catList = bal.GetAll();
                    dgCat.ItemsSource = catList;





                }



            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {


            try
            {

                int id = 0;
                Invoice_Category cat = new Invoice_Category();

                if (int.TryParse(cbCatID.Text, out id))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }



                if (Invoice_CategoryBL.DeleteCategory(id) > 0)
                {
                    MessageBox.Show("Category Deleted!");
                    //cbCatID.Text = null;

                    catList = bal.GetAll();
                    dgCat.ItemsSource = catList;

                    cbCatID.ItemsSource = catList;
                    cbCatID.DisplayMemberPath = "CategoryId";

                }

                
            }
            catch (Invoice_CategoryExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cbCatID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Invoice_Category cat = new Invoice_Category();

            //catList=new List<Invoice_Category>();
            //bal = new Invoice_CategoryBL();
            //catList = bal.GetAll();
            //int id = 0;
            //if(int.TryParse(cbCatID.Text, out id))
            //{ }
            //    foreach (var c in catList)
            //    {
            //        if (id == c.CategoryId)
            //        {
            //            txtCatDescription.Text = cat.Description;
            //            txtCatName.Text = cat.CategoryName;
            //        }
            //        break;

          

            txtCatName.Text=((Invoice_Category)cbCatID.SelectedItem).CategoryName;
            txtCatDescription.Text = ((Invoice_Category)cbCatID.SelectedItem).Description;

                }
        }
         
        }
            
        

    


