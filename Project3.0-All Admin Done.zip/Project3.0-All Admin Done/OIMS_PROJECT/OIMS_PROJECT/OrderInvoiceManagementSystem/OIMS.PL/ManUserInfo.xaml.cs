﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OIMS.BL;
using OIMS.Entity;
using OIMS.Exceptions;

namespace OIMS.PL
{
    /// <summary>
    /// Interaction logic for ManUserInfo.xaml
    /// </summary>
    public partial class ManUserInfo : Window
    {

        Invoice_UsersBL bal = null;
        List<Invoice_Users> userList = null;

        public ManUserInfo()
        {
            InitializeComponent();
            userList = new List<Invoice_Users>();
            bal = new Invoice_UsersBL();
            userList = bal.GetAll();
            dgUser.ItemsSource = userList;


            cbUserID.ItemsSource = userList;
            cbUserID.DisplayMemberPath = "ID";

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Invoice_Users user = new Invoice_Users();
                user.Username = txtUserName.Text;
                user.Password = txtPassword.Password;
                user.Status = txtStatus.Text;


                if (Invoice_UsersBL.InsertUsers(user) > 0)
                {
                    MessageBox.Show("User Information Inserted!");
                    //List<Invoice_Category> catList = new List<Invoice_Category>();
                    userList = bal.GetAll();
                    dgUser.ItemsSource = userList;
                    dgUser.DataContext = userList;


                    cbUserID.ItemsSource = userList;
                    cbUserID.DisplayMemberPath = "ID";
                }



            }
            catch (Invoice_UsersExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Users user = new Invoice_Users();

                if (int.TryParse(cbUserID.Text, out id))
                {
                    user.ID = id;
                    user.Username = txtUserName.Text;
                    user.Password = txtPassword.Password;
                    user.Status = txtStatus.Text;

                }



                if (Invoice_UsersBL.UpdateUsers(user) > 0)
                {
                    MessageBox.Show("User information Updated!");


                    userList = bal.GetAll();
                    dgUser.ItemsSource = userList;
                }
            }
            catch (Invoice_UsersExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Users user = new Invoice_Users();

                if (int.TryParse(cbUserID.Text, out id))
                {

                    //txtCatName.Text = cat.CategoryName;
                    //txtCatDescription.Text = cat.Description;
                }



                if (Invoice_UsersBL.DeleteUsers(id) > 0)
                {
                    MessageBox.Show("User Information Deleted!");
                    //cbCatID.Text = null;

                    userList = bal.GetAll();
                    dgUser.ItemsSource = userList;

                    cbUserID.ItemsSource = userList;
                    cbUserID.DisplayMemberPath = "ID";

                }


            }
            catch (Invoice_UsersExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
