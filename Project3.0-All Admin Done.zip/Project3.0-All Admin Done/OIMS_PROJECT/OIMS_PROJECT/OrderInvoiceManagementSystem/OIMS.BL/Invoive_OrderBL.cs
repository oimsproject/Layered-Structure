﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using OIMS.Exceptions;
using OIMS.Entity;
using OIMS.DAL;

namespace OIMS.BL
{
  public  class Invoive_OrderBL
    {

        public static bool ValidateOrder(Invoice_Order ord)
        {
            bool orderValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (ord.OrderDate > DateTime.Today)
                {
                    message.Append("Order Date should be less than or equal to current date\n");
                    orderValidated = false;
                }
                if (ord.CustomerId == null)
                {
                    orderValidated = false;
                    message.Append("Customer Id should be provided\n");
                }

                if (ord.Amount == null || ord.Amount < 0)
                {
                    orderValidated = false;
                    message.Append("Amount should be provided and can't be negative\n");
                }





                if (orderValidated == false)
                {
                    throw new Invoice_OrderExceptions(message.ToString());
                }
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return orderValidated;
        }


        public static int InsertOrder(Invoice_Order ord)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateOrder(ord))
                {
                    recordsAffected = Invoice_OrderDAL.InsertOrder(ord);
                }
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateOrder(Invoice_Order ord)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_OrderDAL.UpdateOrder(ord);
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteOrder(int oId)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_OrderDAL.DeleteOrder(oId);
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Invoice_Order SearchOrder(int oId)
        {
            Invoice_Order ord = null;

            try
            {
                ord = Invoice_OrderDAL.SearchOrder(oId);
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ord;
        }

        public static List<Invoice_Order> DisplayOrder()
        {
            List<Invoice_Order> ordList = null;

            try
            {
                ordList = Invoice_OrderDAL.DisplayOrder();
            }
            catch (Invoice_OrderExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ordList;
        }
    }
}
