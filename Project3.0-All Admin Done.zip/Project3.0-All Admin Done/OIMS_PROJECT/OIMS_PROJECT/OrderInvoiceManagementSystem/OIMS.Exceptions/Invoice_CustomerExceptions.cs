﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS.Exceptions
{
   public class Invoice_CustomerExceptions:ApplicationException
    {
        public Invoice_CustomerExceptions()
        {

        }
        public Invoice_CustomerExceptions(string message)
            : base(message)
        {

        }
    }
}
