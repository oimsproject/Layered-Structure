﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS.Exceptions
{
   public class Invoice_UsersExceptions:ApplicationException
    {
        public Invoice_UsersExceptions()
        {

        }
        public Invoice_UsersExceptions(string message)
            : base(message)
        {

        }
    }
}
