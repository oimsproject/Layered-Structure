﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_DAL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_BL
{
    public class Invoice_InvoiceBL
    {
         Invoice_InvoiceDAL dal = new Invoice_InvoiceDAL();
        
          public static int InsertInvoice(Invoice_Invoice inv)
        {
            int recordsAffected = 0;

            try
            {
                
                    recordsAffected = Invoice_InvoiceDAL.InsertInvoice(inv);
               
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateInvoice(Invoice_Invoice inv)
        {
            int recordsAffected = 0;

            try
            {   
                    recordsAffected = Invoice_InvoiceDAL.UpdateInvoice(inv);
              
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteInvoice(int invId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_InvoiceDAL.DeleteInvoice(invId);
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public List<Invoice_Invoice> GetAll()
        {
            return dal.SelectAll();
        }
    }
}
    

