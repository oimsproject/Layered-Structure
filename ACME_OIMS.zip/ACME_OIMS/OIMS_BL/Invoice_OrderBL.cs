﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_DAL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_BL
{
    public class Invoice_OrderBL
    {
        Invoice_OrderDAL dal = new Invoice_OrderDAL();
        

        public static int InsertOrder(Invoice_Order ord)
        {
            int recordsAffected = 0;

            try
            {
                    recordsAffected = Invoice_OrderDAL.InsertOrder(ord);
                
            }
            catch (Invoice_OrderException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateOrder(Invoice_Order ord)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_OrderDAL.UpdateOrder(ord);
            }
            catch (Invoice_OrderException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteOrder(int oId)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_OrderDAL.DeleteOrder(oId);
            }
            catch (Invoice_OrderException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        public List<Invoice_Order> GetAll()
        {
            return dal.SelectAll();
        }
    }
}

    

