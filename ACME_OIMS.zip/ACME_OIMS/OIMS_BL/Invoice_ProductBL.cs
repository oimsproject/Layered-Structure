﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_Exception;
using OIMS_Entity;
using OIMS_DAL;

namespace OIMS_BL
{
    public class Invoice_ProductBL
    {
        Invoice_ProductDAL dal = new Invoice_ProductDAL();
        

        public List<Invoice_Product> GetAll()
        {
            return dal.SelectAll();
        }



        public static int InsertProduct(Invoice_Product prod)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_ProductDAL.InsertProduct(prod);
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateProduct(Invoice_Product prod)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_ProductDAL.UpdateProduct(prod);
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteProduct(int pId)
        {
            int recordsAffected;

            try
            {
                recordsAffected = Invoice_ProductDAL.DeleteProduct(pId);
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        public List<Invoice_Product> DisplayAvailableProduct()
        {
            return dal.DisplayAvailableProduct(); 
         
        }
    }
}

    

