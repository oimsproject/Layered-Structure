﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_DAL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_BL
{
    public class Invoice_UsersBL
    {
         Invoice_UsersDAL dal = null;
        public Invoice_UsersBL()
        {
            dal = new Invoice_UsersDAL();
        }
        

        public List<Invoice_Users> GetAll()
        {
            return dal.SelectAll();
        }



        public static int InsertUsers(Invoice_Users user)
        {
            int recordsAffected = 0;

            try
            {              
                    recordsAffected = Invoice_UsersDAL.InsertUsers(user);               
            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateUsers(Invoice_Users user)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_UsersDAL.UpdateUsers(user);             
            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteUsers(string uid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_UsersDAL.DeleteUsers(uid);
            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
      
    }
}

    

