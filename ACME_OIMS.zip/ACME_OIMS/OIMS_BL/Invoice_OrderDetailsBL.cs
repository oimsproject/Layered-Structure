﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_Exception;
using OIMS_Entity;
using OIMS_DAL;

namespace OIMS_BL
{
    public class Invoice_OrderDetailsBL
    {
         Invoice_OrderDetailsDAL dal = new Invoice_OrderDetailsDAL();
       

       public static int InsertDetails(Invoice_OrderDetails ordet)
       {
           int recordsAffected;

           try
           {
               recordsAffected = Invoice_OrderDetailsDAL.InsertDetails(ordet);
           }
           catch (Invoice_OrderDetailsException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       public static int UpdateDetails(Invoice_OrderDetails ordet)
       {
           int recordsAffected;

           try
           {
               recordsAffected = Invoice_OrderDetailsDAL.UpdateDetails(ordet);
           }
           catch (Invoice_OrderDetailsException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       public static int DeleteDetails(int ordet)
       {
           int recordsAffected;

           try
           {
               recordsAffected = Invoice_OrderDetailsDAL.DeleteDetails(ordet);
           }
           catch (Invoice_OrderDetailsException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

     

     
       public List<Invoice_OrderDetails> GetAll()
       {
           return dal.SelectAll();
       }
    }
}
    

