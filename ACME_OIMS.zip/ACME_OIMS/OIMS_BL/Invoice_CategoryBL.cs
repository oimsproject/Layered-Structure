﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_DAL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_BL
{
    public class Invoice_CategoryBL
    {
         Invoice_CategoryDAL dal = null;
        public Invoice_CategoryBL()
        {
            dal = new Invoice_CategoryDAL();
        }
       
        

        public List<Invoice_Category> GetAll()
        {
            return dal.SelectAll();
        }

        public int InsertCategory(Invoice_Category Icat)
        {
            int recordsAffected = 0;

            try 
            {
                    recordsAffected = dal.InsertCategory(Icat);
            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateCategory(Invoice_Category Icat)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_CategoryDAL.UpdateCategory(Icat);
               }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

     

        public static int DeleteCategory(int catId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_CategoryDAL.DeleteCategory(catId);
            }
            catch(Invoice_CategoryException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

     
    }
    }


    

