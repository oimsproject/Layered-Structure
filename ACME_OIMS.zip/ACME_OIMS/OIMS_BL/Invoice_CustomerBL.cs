﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_Exception;
using OIMS_Entity;
using OIMS_DAL;

namespace OIMS_BL
{
    public class Invoice_CustomerBL
    {
        Invoice_CustomerDAL dal = null;
        public Invoice_CustomerBL()
        {
            dal = new Invoice_CustomerDAL();
        }

     
      public List<Invoice_Customer> GetAll()
      {
          return dal.SelectAll();
      }

      public int InsertCustomer(Invoice_Customer Icust)
        {
            int recordsAffected = 0;

            try
            {
               recordsAffected = Invoice_CustomerDAL.InsertCustomer(Icust);               
            }
            catch (Invoice_CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

      public int UpdateCustomer(Invoice_Customer Icust)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_CustomerDAL.UpdateCustomer(Icust);
                
            }
            catch (Invoice_CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

      public int DeleteCustomer(int custId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = Invoice_CustomerDAL.DeleteCustomer(custId);
            }
            catch (Invoice_CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


    }
}

    

