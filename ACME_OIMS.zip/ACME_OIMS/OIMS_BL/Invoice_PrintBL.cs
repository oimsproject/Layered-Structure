﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_DAL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_BL
{
    public class Invoice_PrintBL
    {
        Invoice_PrintDAL dal = new Invoice_PrintDAL();


        public static List< Invoice_Print> PrintInvoice(int invId)
        {
            List<Invoice_Print> inv = null;

            try
            {
                inv = Invoice_PrintDAL.PrintInvoice(invId);
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return inv;
        }



        public static List<Invoice_Customer> CustomerInvoice(int invId)
        {
            List<Invoice_Customer> cus = null;

            try
            {
                cus = Invoice_PrintDAL.CustomerInvoice(invId);
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cus;
        }
    }
}
