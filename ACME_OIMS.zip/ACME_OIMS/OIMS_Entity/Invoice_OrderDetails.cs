﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Order Details
    /// </summary>

    public class Invoice_OrderDetails
    {
        //Get or Set Order Details Id
        public int OrderDetailsId { get; set; }

        //Get or Set Order Id
        public int OrderId { get; set; }

        //Get or Set Product Id
        public int ProductId { get; set; }

        //Get or Set Quantity
        public int Quantity { get; set; }
    }
}
 