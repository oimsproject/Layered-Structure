﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Customer
    /// </summary>
    /// 
    public class Invoice_Customer
    {
        //Get or Set Customer Id
        public int CustomerId { get; set; }

        //Get or Set Customer Name
        public string CustomerName { get; set; }

        //Get or Set Contact
        public string Contact { get; set; }

        //Get or Set Email
        public string Email { get; set; }

        //Get or Set Address
        public string Address { get; set; }

        //Get or Set City
        public string City { get; set; }

        //Get or Set Pincode
        public string Pincode { get; set; }
    }
}
