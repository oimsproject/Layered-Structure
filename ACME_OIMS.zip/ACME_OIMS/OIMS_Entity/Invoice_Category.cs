﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Category
    /// </summary>

    public class Invoice_Category
    {
        //Get or Set Category Id
        public int CategoryId { get; set; }

        //Get or Set Category Name
        public string CategoryName { get; set; }

        //Get or Set Descriptions
        public string Descriptions { get; set; }
    }
}
