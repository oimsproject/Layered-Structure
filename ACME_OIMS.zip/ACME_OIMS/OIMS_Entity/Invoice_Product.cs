﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Product
    /// </summary>

    public class Invoice_Product
    {
        //Get or Set Product Id
        public int ProductId { get; set; }

        //Get or Set Product Name
        public string ProductName { get; set; }

        //Get or Set Unit Price
        public int UnitPrice { get; set; }

        //Get or Set Catgory Id
        public int CategoryId { get; set; }

        //Get or Set Descriptions
        public string Descriptions { get; set; }

        //Get or Set Availability
        public string  Availability { get; set; }
    }
}
