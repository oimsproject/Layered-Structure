﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Print
    /// </summary>

    public class Invoice_Print
    {
        //Get or Set Product Name
        public string ProductName { get; set; }

        //Get or Set Quantity
        public int Quantity { get; set; }

        //Get or Set Unit Price
        public int UnitPrice { get; set; }

        //Get or Set Total
        public int Total { get; set; }
    }
}
