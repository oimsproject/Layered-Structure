﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Users
    /// </summary>

    public class Invoice_Users
    {
        //Get or Set User Name
        public string Username { get; set; }

        //Get or Set Passwords
        public string Passwords { get; set; }

        //Get or Set Statuses
        public string Statuses { get; set; }
    }
}
