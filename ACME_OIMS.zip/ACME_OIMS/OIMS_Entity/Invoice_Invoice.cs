﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Invoice
    /// </summary>
    /// 
    public class Invoice_Invoice
    {
        //Get or Set Invoice Id
        public int InvoiceId { get; set; }

        //Get or Set Order Id
        public int OrderId { get; set; }

        //Get or Set Invoice Date
        public DateTime InvoiceDate { get; set; }
    }
}
