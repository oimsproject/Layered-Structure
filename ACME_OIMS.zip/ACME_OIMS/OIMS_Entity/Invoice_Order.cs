﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Entity
{
    /// <summary>
    /// Group No : 4
    /// Description : This an entity class for Order
    /// </summary>

    public class Invoice_Order
    {
        //Get or Set Order Id
        public int OrderId { get; set; }

        //Get or Set Order Date
        public DateTime OrderDate { get; set; }

        //Get or Set Customer Id
        public int CustomerId { get; set; }
    }
}
