﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using OIMS_Exception;
using OIMS_Entity;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Users
    /// </summary>
    ///

   public class Invoice_UsersDAL
    {
        SqlDataReader dr = null;

        //Function to Display all records
        public List<Invoice_Users> SelectAll()
        {
            List<Invoice_Users> userList = new List<Invoice_Users>();

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Display_Users_OIMS";
                    cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Users user = new Invoice_Users();
                   
                    user.Username = dr[0].ToString();
                    user.Passwords = dr[1].ToString();
                    user.Statuses = dr[2].ToString();
                   

                    userList.Add(user);

                }
                cmd.Connection.Close();
            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                
            }

            return userList;
        }

        //Function to insert records in database
        public static int InsertUsers(Invoice_Users users)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Users_OIMS";

               
                cmd.Parameters.AddWithValue("@UsernameP", users.Username);
                cmd.Parameters.AddWithValue("@PasswordP", users.Passwords);
                cmd.Parameters.AddWithValue("@StatusP", users.Statuses);
               

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

                

            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to update records in database
        public static int UpdateUsers(Invoice_Users users)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Users_OIMS";

               
                cmd.Parameters.AddWithValue("@UsernameP", users.Username);
                cmd.Parameters.AddWithValue("@PasswordP", users.Passwords);
                cmd.Parameters.AddWithValue("@StatusP", users.Statuses);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to delete record from database
        public static int DeleteUsers(string uId)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Users_OIMS";

                cmd.Parameters.AddWithValue("@UsernameP",uId);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_UsersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

          

    }
    }

    
