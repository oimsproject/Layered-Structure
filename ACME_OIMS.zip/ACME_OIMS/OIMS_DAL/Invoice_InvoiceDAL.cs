﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_Exception;
using OIMS_Entity;
using System.Data.SqlClient;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Invoice
    /// </summary>
    ///

    public class Invoice_InvoiceDAL
    {
       
        SqlDataReader dr = null;


        //Function to insert records in database
        public static int InsertInvoice(Invoice_Invoice odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Invoice_OIMS";

                //cmd.Parameters.AddWithValue("@InvoiceIdP", odr.InvoiceId);
                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@InvoiceDateP", odr.InvoiceDate);


                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }


        //Function to update records in database
        public static int UpdateInvoice(Invoice_Invoice odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Invoice_OIMS";

                cmd.Parameters.AddWithValue("@InvoiceIdP", odr.InvoiceId);
                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@InvoiceDateP", odr.InvoiceDate);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to delete record from database
        public static int DeleteInvoice(int Inid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Invoice_OIMS";

                cmd.Parameters.AddWithValue("@InvoiceIdP", Inid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        //Function to Display all records
        public List<Invoice_Invoice> SelectAll()
        {
            List<Invoice_Invoice> iList = new List<Invoice_Invoice>();

            try
            {
               
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Display_Invoice_OIMS";
                    cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Invoice inv = new Invoice_Invoice();
                    inv.InvoiceId = Convert.ToInt32(dr[0]);
                    inv.InvoiceDate = Convert.ToDateTime(dr[2]);
                    inv.OrderId = Convert.ToInt32(dr[1]);
                   

                    iList.Add(inv);

                }
                cmd.Connection.Close();
                
            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                
            }

            return iList;
        }
    }
}
    

