﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Category
    /// </summary>
    ///

  public  class Invoice_OrderDAL
    {
       
        SqlDataReader dr = null;

        //Function to insert records in database
        public static int InsertOrder(Invoice_Order odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Order_OIMS";

                
                cmd.Parameters.AddWithValue("@OrderDateP", odr.OrderDate);
                cmd.Parameters.AddWithValue("@CustomerIdP", odr.CustomerId);
                


                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to update records in database
        public static int UpdateOrder(Invoice_Order odr)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Order_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", odr.OrderId);
                cmd.Parameters.AddWithValue("@OrderDateP", odr.OrderDate);
                cmd.Parameters.AddWithValue("@CustomerIdP", odr.CustomerId);
                

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to delete record from database
        public static int DeleteOrder(int oid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Order_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", oid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }             

        //Function to Display all records
        public List<Invoice_Order> SelectAll()
        {
            List<Invoice_Order> ordList = new List<Invoice_Order>();

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Display_Order_OIMS";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Order ord = new Invoice_Order();
                    ord.OrderId = Convert.ToInt32(dr[0]);
                    ord.OrderDate = Convert.ToDateTime(dr[1]);
                    ord.CustomerId = Convert.ToInt32(dr[2]);
                   

                    ordList.Add(ord);

                }
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
               
            }

            return ordList;
        }

    }
}
