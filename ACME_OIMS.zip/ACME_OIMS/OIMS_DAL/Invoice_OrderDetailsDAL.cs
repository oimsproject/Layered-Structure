﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS_Entity;
using OIMS_Exception;


namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Order Details
    /// </summary>
    ///

    //Function to insert records in database
   public class Invoice_OrderDetailsDAL
    {

       
       SqlDataReader dr = null;

      public static int InsertDetails(Invoice_OrderDetails ordet)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_OrderDetails_OIMS";

                cmd.Parameters.AddWithValue("@OrderIdP", ordet.OrderId);
                cmd.Parameters.AddWithValue("@ProductIdP", ordet.ProductId);
                cmd.Parameters.AddWithValue("@QuantityP ", ordet.Quantity);


                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

      //Function to update records in database
        public static int UpdateDetails(Invoice_OrderDetails ordet)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_OrderDetails_OIMS";
                cmd.Parameters.AddWithValue("@OrderDetailsIdP", ordet.OrderDetailsId);
                cmd.Parameters.AddWithValue("@OrderIdP", ordet.OrderId);
                cmd.Parameters.AddWithValue("@ProductIdP", ordet.ProductId);
                
                cmd.Parameters.AddWithValue("@QuantityP ", ordet.Quantity);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to delete record from database
        public static int DeleteDetails(int OrderDetailsId)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_OrderDetails_OIMS";

                cmd.Parameters.AddWithValue("@OrderDetailsIdP", OrderDetailsId);
               

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_OrderDetailsException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        //Function to Display all records
        public List<Invoice_OrderDetails> SelectAll()
        {
            List<Invoice_OrderDetails> ordList = new List<Invoice_OrderDetails>();

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Display_OrderDetails_OIMS";
                cmd.Connection.Open();


                dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_OrderDetails ord = new Invoice_OrderDetails();
                    ord.OrderDetailsId = Convert.ToInt32(dr[0]);
                    ord.OrderId = Convert.ToInt32(dr[1]);
                    ord.ProductId = Convert.ToInt32(dr[2]);
                    ord.Quantity = Convert.ToInt32(dr[3]);
                    

                    ordList.Add(ord);

                }
            }
            catch (Invoice_OrderDetailsException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
              
            }

            return ordList;
        }

    }
}
