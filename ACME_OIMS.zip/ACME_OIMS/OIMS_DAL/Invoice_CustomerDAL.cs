﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Customer
    /// </summary>
    ///


    public class Invoice_CustomerDAL
    {

        
            SqlDataReader dr = null;

            //Function to Display all records
            public List<Invoice_Customer> SelectAll()
            {
                List<Invoice_Customer> custList = new List<Invoice_Customer>();

                try
                {
                    SqlCommand cmd = DataConnection.GenerateCommand();
                    cmd.CommandText = "USP_Display_Customer_OIMS";
                    cmd.Connection.Open();


                    dr = cmd.ExecuteReader();
                    //To Retreive the record with the help of data reader
                    while (dr.Read())
                    {
                        Invoice_Customer cust = new Invoice_Customer();
                        cust.CustomerId = Convert.ToInt32(dr[0]);
                        cust.CustomerName = dr[1].ToString();
                        cust.Contact = dr[2].ToString();
                        cust.Email = dr[3].ToString();
                        cust.Address = dr[4].ToString();
                        cust.City = dr[5].ToString();
                        cust.Pincode = dr[6].ToString();

                        custList.Add(cust);

                    }

                    cmd.Connection.Close();
                }
                catch (Invoice_CategoryException ex)
                {
                    throw ex;
                }
                finally
                {
                    dr.Close();
                }

                return custList;
            }

            //Function to insert records in database
            public static int InsertCustomer(Invoice_Customer cust)
            {
                int rowsAffected = 0;

                try
                {
                    SqlCommand cmd = DataConnection.GenerateCommand();

                    cmd.CommandText = "USP_Insert_Customer_OIMS";

                   
                    cmd.Parameters.AddWithValue("@CustomerNameP", cust.CustomerName);
                    cmd.Parameters.AddWithValue("@ContactP", cust.Contact);
                    cmd.Parameters.AddWithValue("@EmailP", cust.Email);
                    cmd.Parameters.AddWithValue("@AddressP", cust.Address);
                    cmd.Parameters.AddWithValue("@CityP", cust.City);
                    cmd.Parameters.AddWithValue("@PincodeP", cust.Pincode);

                    cmd.Connection.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
                catch (Invoice_CustomerException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return rowsAffected;
            }

            //Function to update records in database
            public static int UpdateCustomer(Invoice_Customer cust)
            {
                int rowsAffected = 0;

                try
                {
                    SqlCommand cmd = DataConnection.GenerateCommand();

                    cmd.CommandText = "USP_Update_Customer_OIMS";

                    cmd.Parameters.AddWithValue("@CustomerIdP", cust.CustomerId);
                    cmd.Parameters.AddWithValue("@CustomerNameP", cust.CustomerName);
                    cmd.Parameters.AddWithValue("@ContactP", cust.Contact);
                    cmd.Parameters.AddWithValue("@EmailP", cust.Email);
                    cmd.Parameters.AddWithValue("@AddressP", cust.Address);
                    cmd.Parameters.AddWithValue("@CityP", cust.City);
                    cmd.Parameters.AddWithValue("@PincodeP", cust.Pincode);

                    cmd.Connection.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
                catch (Invoice_CustomerException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return rowsAffected;
            }

            //Function to delete record from database
            public static int DeleteCustomer(int cid)
            {
                int recordsAffected = 0;

                try
                {
                    SqlCommand cmd = DataConnection.GenerateCommand();

                    cmd.CommandText = "USP_Delete_Customer_OIMS";

                    cmd.Parameters.AddWithValue("@CustomerIdP", cid);

                    cmd.Connection.Open();
                    recordsAffected = cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
                catch (Invoice_CustomerException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return recordsAffected;
            }
              
            }




        }
    
