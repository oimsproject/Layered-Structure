﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_Exception;
using OIMS_Entity;
using OIMS_DAL;
using System.Data.SqlClient;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Printing
    /// </summary>
    ///

    public class Invoice_PrintDAL
    {

        //Function to Display invoice
        public static List<Invoice_Print> PrintInvoice(int Inid)
        {
            List<Invoice_Print> inList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_PrintInvoice_OIMS";
                cmd.Parameters.AddWithValue("@InvoiceIdP", Inid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    inList = new List<Invoice_Print>();

                    while (dr.Read())
                    {
                        Invoice_Print inOdr = new Invoice_Print();

                        inOdr.ProductName = Convert.ToString(dr["ProductName"]);
                        inOdr.Quantity = Convert.ToInt32(dr["Quantity"]);
                        inOdr.UnitPrice = Convert.ToInt32(dr["UnitPrice"]);
                        inOdr.Total = Convert.ToInt32(dr["Total"]);
                        inList.Add(inOdr);
                    }
                }
                else
                    throw new Invoice_OrderException("Invoice Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return inList;
        }


        //Function to Display Invoice's Customer
        public static List<Invoice_Customer> CustomerInvoice(int Inid)
        {
            List<Invoice_Customer> CustomerList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_GetCustomer_OIMS";
                cmd.Parameters.AddWithValue("@InvoiceIdP", Inid);

                cmd.Connection.Open();
                SqlDataReader dr2 = cmd.ExecuteReader();

                if (dr2.HasRows)
                {
                    CustomerList = new List<Invoice_Customer>();

                    while (dr2.Read())
                    {
                        Invoice_Customer inOdr = new Invoice_Customer();

                        //inOdr.CustomerId=Convert.ToInt32(dr2[0]);
                        inOdr.CustomerName = Convert.ToString(dr2["CustomerName"]);
                        //inOdr.Quantity = Convert.ToInt32(dr["Quantity"]);
                        //inOdr.UnitPrice = Convert.ToInt32(dr["UnitPrice"]);
                        //inOdr.Total = Convert.ToInt32(dr["Total"]);
                        CustomerList.Add(inOdr);
                    }
                }
                else
                    throw new Invoice_CustomerException("Invoice Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_InvoiceException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return CustomerList;
        }

    }
}
