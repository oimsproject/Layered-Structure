﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OIMS_Entity;           
using OIMS_Exception;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Category
    /// </summary>
    ///

    public class Invoice_CategoryDAL
    {
       
        SqlDataReader dr = null;

        //Function to Display all records
        public List<Invoice_Category> SelectAll()
        {
            List<Invoice_Category> catList = new List<Invoice_Category>();

            try
            {
               
                
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Display_Category_OIMS";
                cmd.Connection.Open();
               

                 dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Category cat = new Invoice_Category();
                    cat.CategoryId = Convert.ToInt32(dr[0]);
                    cat.CategoryName = dr[1].ToString();
                    cat.Descriptions = dr[2].ToString();

                    catList.Add(cat);

                }

                cmd.Connection.Close();


            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
               
            }

            return catList;
        }


        //Function to insert records in database
        public int InsertCategory(Invoice_Category cat)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Category_OIMS";

               
                cmd.Parameters.AddWithValue("@CategoryNameP", cat.CategoryName);

                cmd.Parameters.AddWithValue("@DescriptionP", cat.Descriptions);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to update records in database
        public static int UpdateCategory(Invoice_Category cat)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Category_OIMS";

                cmd.Parameters.AddWithValue("@CategoryIdP", cat.CategoryId);
                cmd.Parameters.AddWithValue("@CategoryNameP", cat.CategoryName);

                cmd.Parameters.AddWithValue("@DescriptionP", cat.Descriptions);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to delete record from database
        public static int DeleteCategory(int cid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Category_OIMS";

                cmd.Parameters.AddWithValue("@CategoryIdP", cid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_CategoryException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

     
     

    }
}
