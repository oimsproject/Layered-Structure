﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_Entity;
using OIMS_Exception;
using System.Data.SqlClient;

namespace OIMS_DAL
{
    /// <summary>
    /// Group No : 4
    /// Description : This an DAL class for Product
    /// </summary>
    ///

    public class Invoice_ProductDAL
    {
        
        SqlDataReader dr = null;
        SqlDataReader dr2 = null;

        //Function to Display all records
        public List<Invoice_Product> SelectAll()
        {
            List<Invoice_Product> prodList = new List<Invoice_Product>();

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Display_Product_OIMS";
                    cmd.Connection.Open();
               
                    dr = cmd.ExecuteReader();
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Invoice_Product prod = new Invoice_Product();
                    prod.ProductId = Convert.ToInt32(dr[0]);
                    prod.ProductName = dr[1].ToString();
                    prod.UnitPrice = Convert.ToInt32(dr[2]);                 
                    prod.CategoryId = Convert.ToInt32(dr[3]);
                    prod.Descriptions = dr[4].ToString(); 
                    prod.Availability=dr[5].ToString();

                    prodList.Add(prod);

                }
                cmd.Connection.Close();
                 
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
               
            }

            return prodList;
        }

        //Function to insert records in database
        public static int InsertProduct(Invoice_Product prod)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Insert_Product_OIMS";

               
                cmd.Parameters.AddWithValue("@ProductNameP", prod.ProductName);
                cmd.Parameters.AddWithValue("@UnitPriceP ", prod.UnitPrice);          
                cmd.Parameters.AddWithValue("@CategoryIdP", prod.CategoryId);
                cmd.Parameters.AddWithValue("@DescriptionP", prod.Descriptions);
                cmd.Parameters.AddWithValue("@AvailabilityP", prod.Availability);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }


        //Function to update records in database
        public static int UpdateProduct(Invoice_Product prod)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Update_Product_OIMS";

                 cmd.Parameters.AddWithValue("@ProductIdP", prod.ProductId);
                cmd.Parameters.AddWithValue("@ProductNameP", prod.ProductName);
                cmd.Parameters.AddWithValue("@UnitPriceP ", prod.UnitPrice);          
                cmd.Parameters.AddWithValue("@CategoryIdP", prod.CategoryId);
                cmd.Parameters.AddWithValue("@DescriptionP", prod.Descriptions);
                cmd.Parameters.AddWithValue("@AvailabilityP", prod.Availability);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }


        //Function to delete record from database
        public static int DeleteProduct(int pid)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Delete_Product_OIMS";

                cmd.Parameters.AddWithValue("@ProductIdP", pid);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to Display some records
        public List<Invoice_Product> DisplayAvailableProduct()
        {
            List<Invoice_Product> prodList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "USP_Available_Product_OIMS";

                cmd.Connection.Open();
                SqlDataReader dr2 = cmd.ExecuteReader();

                if (dr2.HasRows)
                {
                    prodList = new List<Invoice_Product>();

                    while (dr2.Read())
                    {
                        Invoice_Product prod = new Invoice_Product();

                        prod.ProductId = Convert.ToInt32(dr2[0]);
                        prod.ProductName = dr2[1].ToString();
                        prod.UnitPrice = Convert.ToInt32(dr2[2]);                      
                        prod.CategoryId = Convert.ToInt32(dr2[3]);
                        prod.Descriptions = dr2[4].ToString();
                        prod.Availability=dr2[5].ToString();



                        prodList.Add(prod);
                    }
                }
                else
                    throw new Invoice_ProductException("Product Details not Available");
                cmd.Connection.Close();
            }
            catch (Invoice_ProductException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }
    }
}
    

