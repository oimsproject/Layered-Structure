﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Exception
{
    /// <summary>
    /// Group No : 4
    /// Description : This an Exception class for Order
    /// </summary>
    ///

   public  class Invoice_OrderException:ApplicationException
    {

       public Invoice_OrderException()
       {

       }
       public Invoice_OrderException(string message):base(message)
       {

       }
    }
}
