﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Exception
{
    /// <summary>
    /// Group No : 4
    /// Description : This an Exception class for Order Details
    /// </summary>
    ///


   public class Invoice_OrderDetailsException:ApplicationException
    {

        public Invoice_OrderDetailsException()
        {

        }
        public Invoice_OrderDetailsException(string message)
            : base(message)
        {

        }

    }
}
