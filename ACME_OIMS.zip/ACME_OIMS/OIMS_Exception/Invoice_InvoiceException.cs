﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Exception
{
    /// <summary>
    /// Group No : 4
    /// Description : This an Exception class for Invoice
    /// </summary>
    ///

  public  class Invoice_InvoiceException:ApplicationException
    {

        public Invoice_InvoiceException()
        {

        }
        public Invoice_InvoiceException(string message)
            : base(message)
        {

        }


    }
}
