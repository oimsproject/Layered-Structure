﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Exception
{
    /// <summary>
    /// Group No : 4
    /// Description : This an Exception class for Product
    /// </summary>
    ///

 public   class Invoice_ProductException:ApplicationException
    {

          public Invoice_ProductException()
       {

       }
          public Invoice_ProductException(string message)
              : base(message)
       {

       }

    }
}
