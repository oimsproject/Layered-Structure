﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_Exception
{
    /// <summary>
    /// Group No : 4
    /// Description : This an Exception class for Category
    /// </summary>
    ///

    public class Invoice_CategoryException:ApplicationException
    {
        
           public Invoice_CategoryException()
        {

        }
        public Invoice_CategoryException(string message)
            : base(message)
        {

        }
    }
}
