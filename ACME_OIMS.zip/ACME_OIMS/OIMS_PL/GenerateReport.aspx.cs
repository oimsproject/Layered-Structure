﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OIMS_PL
{
    public partial class GenerateReport : System.Web.UI.Page
    {
        Training_13Dec17_Hinjawadi_PuneEntities dbcontext = null;


        protected void Page_Load(object sender, EventArgs e)
        {
            
            dbcontext = new Training_13Dec17_Hinjawadi_PuneEntities();

       }

        

        protected void btnGenReport_Click1(object sender, EventArgs e)
        {

            DateTime k = Convert.ToDateTime(calFromDate.VisibleDate.Date);
            DateTime j = Convert.ToDateTime(calToDate.SelectedDate);





            var res = (from a in dbcontext.OIMS_Order
                       join b in dbcontext.OIMS_OrderDetails on a.OrderId equals b.OrderId
                        join c in dbcontext.OIMS_Product on b.ProductId equals c.ProductId
                        where a.OrderDate>=k && a.OrderDate<=j                    
                       select new { c.ProductId,b.Quantity,c.UnitPrice,Multiply=b.Quantity*c.UnitPrice}).ToList();

            


            dgGenReport.DataSource = res;
            dgGenReport.DataBind();


        }

        protected void btnGenSum_Click(object sender, EventArgs e)
        {
            DateTime k = Convert.ToDateTime(calFromDate.VisibleDate.Date);
            DateTime j = Convert.ToDateTime(calToDate.SelectedDate);

            var res = (from a in dbcontext.OIMS_Order
                       join b in dbcontext.OIMS_OrderDetails on a.OrderId equals b.OrderId
                       join c in dbcontext.OIMS_Product on b.ProductId equals c.ProductId
                       where a.OrderDate >= k && a.OrderDate <= j
                       select b.Quantity * c.UnitPrice ).Sum();

            txtAmount.Text = Convert.ToString(res);
        }
    }
}