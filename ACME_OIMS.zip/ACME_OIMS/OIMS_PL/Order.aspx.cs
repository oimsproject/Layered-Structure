﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_Entity;
using OIMS_Exception;
using OIMS_BL;

namespace OIMS_PL
{
    public partial class Order : System.Web.UI.Page
    {
        Invoice_OrderBL bal = new Invoice_OrderBL();
        List<Invoice_Order> ordList = new List<Invoice_Order>();
        Invoice_CustomerBL cbal = new Invoice_CustomerBL();
        List<Invoice_Customer> cuslist = new List<Invoice_Customer>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ordList = bal.GetAll();
                dgCategoryID.DataSource = ordList;
                dgCategoryID.DataBind();

                ddlOrderID.DataSource = ordList;
                ddlOrderID.DataValueField = "OrderId";
                ddlOrderID.DataBind();

                cuslist = cbal.GetAll();
                ddlCustomerID.DataSource = cuslist;
                ddlCustomerID.DataValueField = "CustomerId";
                ddlCustomerID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                Invoice_Order ord = new Invoice_Order();
                ord.OrderDate = Convert.ToDateTime(calOrderDate.SelectedDate);
                ord.CustomerId = Convert.ToInt32(ddlCustomerID.Text);

                if (Invoice_OrderBL.InsertOrder(ord) > 0)
                {
                    Response.Write("<script>alert('Order Inserted');</script>");
                    //List<Invoice_Category> catList = new List<Invoice_Category>();
                    ordList = bal.GetAll();
                    dgCategoryID.DataSource = ordList;
                    dgCategoryID.DataBind();

                    ddlOrderID.DataSource = ordList;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();

                    cuslist = cbal.GetAll();
                    ddlCustomerID.DataSource = cuslist;
                    ddlCustomerID.DataValueField = "CustomerId";
                    ddlCustomerID.DataBind();
                }

            }
            catch (Invoice_OrderException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }



        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Order ord = new Invoice_Order();

                if (int.TryParse(ddlOrderID.Text, out id))
                {
                    ord.OrderId = id;
                    ord.OrderDate = Convert.ToDateTime(calOrderDate.SelectedDate);
                    ord.CustomerId = Convert.ToInt32(ddlCustomerID.Text);
                }



                if (Invoice_OrderBL.UpdateOrder(ord) > 0)
                {
                    Response.Write("<script>alert('Order Updated');</script>");

                  
                    ordList = bal.GetAll();
                    dgCategoryID.DataSource = ordList;
                    dgCategoryID.DataBind();

                    ddlOrderID.DataSource = ordList;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();

                    cuslist = cbal.GetAll();
                    ddlCustomerID.DataSource = cuslist;
                    ddlCustomerID.DataValueField = "CustomerId";
                    ddlCustomerID.DataBind();
                }

            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Order ord = new Invoice_Order();

                if (int.TryParse(ddlOrderID.Text, out id))
                {

                    
                }



                if (Invoice_OrderBL.DeleteOrder(id) > 0)
                {
                    Response.Write("<script>alert('Order Deleted');</script>");
                   
                    ordList = bal.GetAll();
                    dgCategoryID.DataSource = ordList;
                    dgCategoryID.DataBind();

                    ddlOrderID.DataSource = ordList;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();

                    cuslist = cbal.GetAll();
                    ddlCustomerID.DataSource = cuslist;
                    ddlCustomerID.DataValueField = "CustomerId";
                    ddlCustomerID.DataBind();
                }


            }
            catch (Invoice_OrderException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void ddlOrderID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(ddlOrderID.Text);
            ordList = bal.GetAll();

            foreach (var item in ordList)
            {
                if (id == item.OrderId)
                {
                    calOrderDate.VisibleDate = item.OrderDate;
                    calOrderDate.SelectedDate = item.OrderDate;
                    
                   
                    
                }
            }
        }
    }
}