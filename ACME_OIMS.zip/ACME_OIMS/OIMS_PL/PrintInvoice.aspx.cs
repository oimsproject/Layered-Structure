﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_BL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_PL
{
    public partial class PrintInvoice : System.Web.UI.Page
    {
        Invoice_InvoiceBL ibal = new Invoice_InvoiceBL();
        List<Invoice_Invoice> invlist = new List<Invoice_Invoice>();
        Invoice_PrintBL pbal = new Invoice_PrintBL();
        List<Invoice_Print> plist = new List<Invoice_Print>();
        List<Invoice_Customer> cuslist = new List<Invoice_Customer>();

        protected void Page_Load(object sender, EventArgs e)
        {
            invlist = ibal.GetAll();
            if (!IsPostBack)
            {
                ddlInvoiceID.DataSource = invlist;
                ddlInvoiceID.DataValueField = "InvoiceId";
                ddlInvoiceID.DataBind();
            }
        }

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Invoice inv = new Invoice_Invoice();
               

                if (int.TryParse(ddlInvoiceID.Text, out id))
                {
                    
                }

                int sum = 0;

                plist= Invoice_PrintBL.PrintInvoice(id);
                {

                    foreach( var k in plist)
                    {
                        sum = sum + (k.Quantity * k.UnitPrice);
                    }
                    txtTotal.Text =Convert.ToString(sum);

                    Response.Write("<script>alert('Invoice Printed');</script>");

                   

                    dgPrintInvoice.DataSource = plist;
                    dgPrintInvoice.DataBind();

                    invlist = ibal.GetAll();
                    ddlInvoiceID.DataSource = invlist;
                    ddlInvoiceID.DataValueField = "InvoiceId";
                    ddlInvoiceID.DataBind();

                }

                cuslist = Invoice_PrintBL.CustomerInvoice(id);
                {
                    foreach (var item in cuslist)
                    {
                        txtCustomerName.Text = item.CustomerName;
                    }
	
                    
                }



            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void ddlInvoiceID_SelectedIndexChanged(object sender, EventArgs e)
        {
             int id = Convert.ToInt32(ddlInvoiceID.SelectedValue);
            invlist = ibal.GetAll();

            foreach (var item in invlist)
            {
                if (id == item.InvoiceId)
                {
                    txtInvoiceDate.Text = Convert.ToString(item.InvoiceDate);
                    break;
                }
            }
        }
    }
}