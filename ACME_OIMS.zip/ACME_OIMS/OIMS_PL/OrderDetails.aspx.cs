﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_BL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_PL
{
    public partial class OrderDetails : System.Web.UI.Page
    {
        Invoice_OrderDetailsBL bal = new Invoice_OrderDetailsBL();
        List<Invoice_OrderDetails> orddList = new List<Invoice_OrderDetails>();

        Invoice_OrderBL ordbal = new Invoice_OrderBL();
        List<Invoice_Order> ordlist = new List<Invoice_Order>();

        Invoice_ProductBL pbal = new Invoice_ProductBL();
        List<Invoice_Product> plist = new List<Invoice_Product>();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                orddList = bal.GetAll();
                dgOrderDetails.DataSource = orddList;
                dgOrderDetails.DataBind();

                ddlOrderDetailsID.DataSource = orddList;
                ddlOrderDetailsID.DataValueField = "OrderDetailsId";
                ddlOrderDetailsID.DataBind();

                ordlist = ordbal.GetAll();
                ddlOrderID.DataSource = ordlist;
                ddlOrderID.DataValueField = "OrderId";
                ddlOrderID.DataBind();

                plist = pbal.DisplayAvailableProduct();
                ddlProductID.DataSource = plist;
                ddlProductID.DataValueField = "ProductId";
                ddlProductID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                Invoice_OrderDetails ordd = new Invoice_OrderDetails();
                ordd.OrderId = Convert.ToInt32(ddlOrderID.Text);
                ordd.ProductId = Convert.ToInt32(ddlProductID.Text);
                ordd.Quantity = Convert.ToInt32(txtQuantity.Text);

                if (Invoice_OrderDetailsBL.InsertDetails(ordd) > 0)
                {
                    Response.Write("<script>alert('OrderDetails Inserted');</script>");
                 
                    orddList = bal.GetAll();
                    dgOrderDetails.DataSource = orddList;
                    dgOrderDetails.DataBind();

                    ddlOrderDetailsID.DataSource = orddList;
                    ddlOrderDetailsID.DataValueField = "OrderDetailsId";
                    ddlOrderDetailsID.DataBind();

                    ordlist = ordbal.GetAll();
                    ddlOrderID.DataSource = ordlist;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();

                    plist = pbal.DisplayAvailableProduct();
                    ddlProductID.DataSource = plist;
                    ddlProductID.DataValueField = "ProductId";
                    ddlProductID.DataBind();
                }

            }
            catch (Invoice_OrderDetailsException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_OrderDetails ordd = new Invoice_OrderDetails();

                if (int.TryParse(ddlOrderDetailsID.Text, out id))
                {
                    ordd.OrderDetailsId = id;
                    ordd.OrderId = Convert.ToInt32(ddlOrderID.Text);
                    ordd.ProductId = Convert.ToInt32(ddlProductID.Text);
                    ordd.Quantity = Convert.ToInt32(txtQuantity.Text);
                }



                if (Invoice_OrderDetailsBL.UpdateDetails(ordd) > 0)
                {
                    Response.Write("<script>alert('OrderDetails Updated');</script>");

                
                    orddList = bal.GetAll();
                    dgOrderDetails.DataSource = orddList;
                    dgOrderDetails.DataBind();

                    ddlOrderDetailsID.DataSource = orddList;
                    ddlOrderDetailsID.DataValueField = "OrderDetailsId";
                    ddlOrderDetailsID.DataBind();

                    ordlist = ordbal.GetAll();
                    ddlOrderID.DataSource = ordlist;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();

                    plist = pbal.DisplayAvailableProduct();
                    ddlProductID.DataSource = plist;
                    ddlProductID.DataValueField = "ProductId";
                    ddlProductID.DataBind();
                }

            }
            catch (Invoice_OrderDetailsException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_OrderDetails cat = new Invoice_OrderDetails();

                if (int.TryParse(ddlOrderDetailsID.Text, out id))
                {

                   
                }



                if (Invoice_OrderDetailsBL.DeleteDetails(id) > 0)
                {
                    Response.Write("<script>alert('OrderDetails Deleted');</script>");
                  
                    orddList = bal.GetAll();
                    dgOrderDetails.DataSource = orddList;
                    dgOrderDetails.DataBind();

                    ddlOrderDetailsID.DataSource = orddList;
                    ddlOrderDetailsID.DataValueField = "OrderDetailsId";
                    ddlOrderDetailsID.DataBind();

                    ordlist = ordbal.GetAll();
                    ddlOrderID.DataSource = ordlist;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();

                    plist = pbal.DisplayAvailableProduct();
                    ddlProductID.DataSource = plist;
                    ddlProductID.DataValueField = "ProductId";
                    ddlProductID.DataBind();
                }


            }
            catch (Invoice_OrderDetailsException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
    }
}