﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_Exception;
using OIMS_Entity;
using OIMS_BL;

namespace OIMS_PL
{
    public partial class GenerateInvoice : System.Web.UI.Page
    {
        Invoice_OrderBL bal = new Invoice_OrderBL();
        List<Invoice_Order> ordList = new List<Invoice_Order>();
        Invoice_InvoiceBL ibal = new Invoice_InvoiceBL();
        List<Invoice_Invoice> invlist = new List<Invoice_Invoice>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                invlist = ibal.GetAll();
                dgInvoice.DataSource = invlist;
                dgInvoice.DataBind();

                ddlInvoiceID.DataSource = invlist;
                ddlInvoiceID.DataValueField = "InvoiceId";
                ddlInvoiceID.DataBind();

                ordList = bal.GetAll();
                ddlOrderID.DataSource = ordList;
                ddlOrderID.DataValueField = "OrderId";
                ddlOrderID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                Invoice_Invoice inv = new Invoice_Invoice();
                inv.InvoiceDate = Convert.ToDateTime(calInvoiceDate.SelectedDate);
                inv.OrderId = Convert.ToInt32(ddlOrderID.Text);

                if (Invoice_InvoiceBL.InsertInvoice(inv) > 0)
                {
                    Response.Write("<script>alert('Invoice Inserted');</script>");
                 
                    invlist = ibal.GetAll();
                    dgInvoice.DataSource = invlist;
                    dgInvoice.DataBind();

                    ddlInvoiceID.DataSource = invlist;
                    ddlInvoiceID.DataValueField = "InvoiceId";
                    ddlInvoiceID.DataBind();

                    ordList = bal.GetAll();
                    ddlOrderID.DataSource = ordList;
                    ddlOrderID.DataValueField = "OrderId";
                    ddlOrderID.DataBind();
                }

            }
            catch (Invoice_OrderException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}