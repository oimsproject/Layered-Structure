﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_BL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_PL
{
    public partial class Login : System.Web.UI.Page
    {
         


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Invoice_Users user = new Invoice_Users();
                List<Invoice_Users> userlist = new List<Invoice_Users>();
                Invoice_UsersBL userbl=new Invoice_UsersBL();


               
               string username = txtUserName.Text;
               string password = txtPassword.Text;

                   userlist = userbl.GetAll();

                   int a = 0;

                  foreach (var k in userlist)
                {
                    if (k.Username == username && k.Passwords == password)
                    {
                        a = a + 1; 
                        if (k.Statuses == "Administrator")
                        {

                            Session["user"] = username;
                            Response.Redirect("User.aspx");
                        }

                        else if (k.Statuses=="Clerk")
                        {
                            Session["user"] = username;
                            Response.Redirect("Order.aspx");
                        }
                        else
                        {
                           
                           
                            break;
                        }
                        
                    }
                                   
                }
                  if (a == 0)
                  {
                      Response.Write("<script>alert('Enter Valid Username And Password');</script>");

                  }
        
            }
            catch (Invoice_UsersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}