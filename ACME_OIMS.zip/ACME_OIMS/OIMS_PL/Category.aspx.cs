﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_Exception;
using OIMS_Entity;
using OIMS_BL;

namespace OIMS_PL
{
    public partial class Category : System.Web.UI.Page
    {
        Invoice_CategoryBL bal = new Invoice_CategoryBL();
        List<Invoice_Category> catList = new List<Invoice_Category>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {              
            catList = bal.GetAll();
            dgCategory.DataSource = catList;
            dgCategory.DataBind();

            ddlCategoryID.DataSource = catList;
            ddlCategoryID.DataValueField = "CategoryId";
            ddlCategoryID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                Invoice_Category cat = new Invoice_Category();
                cat.CategoryName = txtCategoryName.Text;

                cat.Descriptions = txtDescription.Text;

                if (bal.InsertCategory(cat) > 0)
                {
                    Response.Write("<script>alert('Category Inserted');</script>");
                   
                    catList = bal.GetAll();
                    dgCategory.DataSource = catList;
                    dgCategory.DataBind();

                    ddlCategoryID.DataSource = catList;
                    ddlCategoryID.DataValueField = "CategoryId";
                    ddlCategoryID.DataBind();
                }

            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }



        protected void btnUpdate_Click(object sender, EventArgs e)
                {
            try
            {

                int id = 0;
                Invoice_Category cat = new Invoice_Category();

                    if (int.TryParse(ddlCategoryID.Text, out id))
                {
                    cat.CategoryId = id;
                    cat.CategoryName = txtCategoryName.Text;

                    cat.Descriptions = txtDescription.Text;
                }



                if (Invoice_CategoryBL.UpdateCategory(cat) > 0)
                {
                    Response.Write("<script>alert('Category Updated');</script>");

                   
                    List<Invoice_Category> clist = new List<Invoice_Category>();
                    clist = bal.GetAll();
                    dgCategory.DataSource = clist;
                    dgCategory.DataBind();

                    ddlCategoryID.DataSource = clist;
                    ddlCategoryID.DataValueField = "CategoryId";
                    ddlCategoryID.DataBind();
                }

            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Category cat = new Invoice_Category();

                if (int.TryParse(ddlCategoryID.Text, out id))
                {

                    
                }



                if (Invoice_CategoryBL.DeleteCategory(id) > 0)
                {
                    Response.Write("<script>alert('Category Deleted');</script>");
                    

                    List<Invoice_Category> clist = new List<Invoice_Category>();
                    clist = bal.GetAll();
                    dgCategory.DataSource = clist;
                    dgCategory.DataBind();

                    ddlCategoryID.DataSource = clist;
                    ddlCategoryID.DataValueField = "CategoryId";
                    ddlCategoryID.DataBind();
                }


            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void ddlCategoryID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(ddlCategoryID.Text);
            catList = bal.GetAll();
            foreach (var item in catList)
            {
                if(item.CategoryId == id)
                {
                    txtCategoryName.Text = item.CategoryName;
                    txtDescription.Text = item.Descriptions;
                    break;
                }
            }
        }
    }
}