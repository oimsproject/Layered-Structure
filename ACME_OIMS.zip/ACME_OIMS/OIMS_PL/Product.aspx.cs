﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_Exception;
using OIMS_BL;
using OIMS_Entity;

namespace OIMS_PL
{
    public partial class Product : System.Web.UI.Page
    {
        Invoice_ProductBL bal = new Invoice_ProductBL();
        List<Invoice_Product> prodList = new List<Invoice_Product>();
        Invoice_CategoryBL cbal = new Invoice_CategoryBL();
        List<Invoice_Category> catList = new List<Invoice_Category>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                prodList = bal.GetAll();
                dgProduct.DataSource = prodList;
                dgProduct.DataBind();

                ddlProductID.DataSource = prodList;
                ddlProductID.DataValueField = "ProductId";
                ddlProductID.DataBind();

                catList = cbal.GetAll();
                ddlProdCategoryID.DataSource = catList;
                ddlProdCategoryID.DataValueField = "CategoryId";
                ddlProdCategoryID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                Invoice_Product prod = new Invoice_Product();
                prod.ProductName = txtProductName.Text;
                prod.UnitPrice = Convert.ToInt32(txtUnitPrice.Text);
                prod.CategoryId = Convert.ToInt32(ddlProdCategoryID.Text);
                prod.Descriptions = txtProdDescription.Text;
                prod.Availability = ddlAvailable.Text;

                if (Invoice_ProductBL.InsertProduct(prod) > 0)
                {
                    Response.Write("<script>alert('Product Inserted');</script>");
                    
                    prodList = bal.GetAll();
                    dgProduct.DataSource = prodList;
                    dgProduct.DataBind();

                    ddlProductID.DataSource = prodList;
                    ddlProductID.DataValueField = "ProductId";
                    ddlProductID.DataBind();

                    catList = cbal.GetAll();
                    ddlProdCategoryID.DataSource = catList;
                    ddlProdCategoryID.DataValueField = "CategoryId";
                    ddlProdCategoryID.DataBind();
                }

            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Product prod = new Invoice_Product();

                if (int.TryParse(ddlProductID.Text, out id))
                {
                    prod.ProductId = id;
                    prod.ProductName = txtProductName.Text;
                    prod.UnitPrice = Convert.ToInt32(txtUnitPrice.Text);
                    prod.CategoryId = Convert.ToInt32(ddlProdCategoryID.Text);
                    prod.Descriptions = txtProdDescription.Text;
                    prod.Availability = ddlAvailable.Text;
                }



                if (Invoice_ProductBL.UpdateProduct(prod) > 0)
                {
                    Response.Write("<script>alert('Product Updated');</script>");

                   
                    prodList = bal.GetAll();
                    dgProduct.DataSource = prodList;
                    dgProduct.DataBind();

                    ddlProductID.DataSource = prodList;
                    ddlProductID.DataValueField = "ProductId";
                    ddlProductID.DataBind();

                    catList = cbal.GetAll();
                    ddlProdCategoryID.DataSource = catList;
                    ddlProdCategoryID.DataValueField = "CategoryId";
                    ddlProdCategoryID.DataBind();
                }

            }
            catch (Invoice_CategoryException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void ddlProductID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(ddlProductID.Text);
            prodList = bal.GetAll();

            foreach (var item in prodList)
            {
                if(id== item.ProductId)
                {
                    txtProductName.Text = item.ProductName;
                    txtProdDescription.Text = item.Descriptions;
                    txtUnitPrice.Text = Convert.ToString(item.UnitPrice);
                }
            }
        }
    }
}