﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_BL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_PL
{
    public partial class User : System.Web.UI.Page
    {
        Invoice_UsersBL bal = null;
        List<Invoice_Users> userList = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            userList = new List<Invoice_Users>();
            bal = new Invoice_UsersBL();
            userList = bal.GetAll();
            dgUser.DataSource = userList;
            dgUser.DataBind();



        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {


                Invoice_Users user = new Invoice_Users();
                user.Username = txtUserName.Text;
                user.Passwords = txtPassword.Text;
                user.Statuses = ddlStatus.Text;


                if (Invoice_UsersBL.InsertUsers(user) > 0)
                {
                    Response.Write("<script>alert('User Information Inserted');</script>");
                 
                    userList = bal.GetAll();
                    dgUser.DataSource = userList;
                    dgUser.DataBind();
                  


                   
                }



            }
            catch (Invoice_UsersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
               
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                string name = txtUserName.Text;
                Invoice_Users user = new Invoice_Users();
                
                    user.Username = name;
                    user.Passwords = txtPassword.Text;
                    user.Statuses = ddlStatus.Text;

               
                if (Invoice_UsersBL.UpdateUsers(user) > 0)
                {
                    Response.Write("<script>alert('User Information Updated');</script>");


                    userList = bal.GetAll();
                    dgUser.DataSource = userList;
                    dgUser.DataBind();
                }
            }
            catch (Invoice_UsersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                string name = txtUserName.Text;
                Invoice_Users user = new Invoice_Users();


                if (Invoice_UsersBL.DeleteUsers(name) > 0)
                {
                    Response.Write("<script>alert('User Information Deleted');</script>");
                    

                    userList = bal.GetAll();
                    dgUser.DataSource= userList;
                    dgUser.DataBind();

                   

                }


            }
            catch (Invoice_UsersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}