﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OIMS_BL;
using OIMS_Entity;
using OIMS_Exception;

namespace OIMS_PL
{
    public partial class Customer : System.Web.UI.Page
    {
        Invoice_CustomerBL bal = new Invoice_CustomerBL();
        List<Invoice_Customer> catList = new List<Invoice_Customer>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                catList = bal.GetAll();
                dgCustomer.DataSource = catList;
                dgCustomer.DataBind();

                ddlCustomerID.DataSource = catList;
                ddlCustomerID.DataValueField = "CustomerId";
                ddlCustomerID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                Invoice_Customer cat = new Invoice_Customer();
                cat.CustomerName = txtCustomerName.Text;

                cat.Contact = txtContactNo.Text;
                cat.Email = txtEmail.Text;
                cat.Address = txtAddress.Text;
                cat.City = txtCity.Text;
                cat.Pincode = txtPincode.Text;


                if (bal.InsertCustomer(cat) > 0)
                {
                    Response.Write("<script>alert('Customer Detail Inserted');</script>");

                    
                    catList = bal.GetAll();
                    dgCustomer.DataSource = catList;
                    dgCustomer.DataBind();

                    ddlCustomerID.DataSource = catList;
                    ddlCustomerID.DataValueField = "CustomerId";
                    ddlCustomerID.DataBind();
                }

            }
            catch (Invoice_CustomerException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                Invoice_Customer cat = new Invoice_Customer();

                if (int.TryParse(ddlCustomerID.Text, out id))
                {
                    cat.CustomerId = id;
                    cat.CustomerName = txtCustomerName.Text;

                    cat.Contact = txtContactNo.Text;
                    cat.Email = txtEmail.Text;
                    cat.Address = txtAddress.Text;
                    cat.City = txtCity.Text;
                    cat.Pincode = txtPincode.Text;
                }



                if (bal.UpdateCustomer(cat) > 0)
                {
                    Response.Write("<script>alert('Customer Detail Updated');</script>");

                 
                    List<Invoice_Customer> clist = new List<Invoice_Customer>();
                    clist = bal.GetAll();
                    dgCustomer.DataSource = clist;
                    dgCustomer.DataBind();

                    ddlCustomerID.DataSource = clist;
                    ddlCustomerID.DataValueField = "CustomerId";
                    ddlCustomerID.DataBind();
                }

            }
            catch (Invoice_CustomerException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void ddlCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {

            int id = Convert.ToInt32(ddlCustomerID.Text);
            catList = bal.GetAll();
            foreach (var item in catList)
            {
                if (item.CustomerId == id)
                {
                    txtCustomerName.Text = item.CustomerName;
                    txtContactNo.Text = item.Contact;
                    txtEmail.Text = item.Email;
                    txtAddress.Text = item.Address;
                    txtCity.Text = item.City;
                    txtPincode.Text = item.Pincode;
                    break;
                }
            }
        }

      
    }
}